using ExternalSessionWebApi.Interfaces;
using ExternalSessionWebApi.Services;
using ExternalSessionWebApi.Models;
using ExternalSessionWebApi.Data;
using ExternalSessionWebApi.Stores;
using ExternalSessionWebApi.Middleware;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using StackExchange.Redis;

var builder = WebApplication.CreateBuilder(args);

// Configure logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

if (builder.Environment.IsDevelopment())
{
    builder.Logging.SetMinimumLevel(LogLevel.Debug);
}
else
{
    builder.Logging.SetMinimumLevel(LogLevel.Information);
}

// Configure session settings
builder.Services.Configure<SessionConfiguration>(
    builder.Configuration.GetSection("SessionConfiguration"));

// Configure data providers based on session configuration
var sessionConfig = builder.Configuration.GetSection("SessionConfiguration").Get<SessionConfiguration>();

if (sessionConfig?.Provider?.ToLowerInvariant() == "redis")
{
    builder.Services.AddSingleton<IConnectionMultiplexer>(provider =>
    {
        var configuration = ConfigurationOptions.Parse(sessionConfig.ConnectionString);
        return ConnectionMultiplexer.Connect(configuration);
    });
}
else
{
    // Configure Entity Framework for SQL-based providers
    builder.Services.AddDbContext<SessionDbContext>(options =>
    {
        switch (sessionConfig?.Provider?.ToLowerInvariant())
        {
            case "sqlserver":
                options.UseSqlServer(sessionConfig.ConnectionString);
                break;
            case "postgresql":
                options.UseNpgsql(sessionConfig.ConnectionString);
                break;
            case "sqlite":
            default:
                options.UseSqlite(sessionConfig?.ConnectionString ?? "Data Source=sessions.db");
                break;
        }
    });

    builder.Services.AddScoped<SqlSessionStore>();
}

// Add Windows Authentication
builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme)
    .AddNegotiate();

builder.Services.AddAuthorization(options =>
{
    // Require authentication for all endpoints by default
    options.FallbackPolicy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
});

// Register services
builder.Services.AddScoped<IWindowsAuthenticationService, WindowsAuthenticationService>();
builder.Services.AddSingleton<SessionStoreFactory>();
builder.Services.AddScoped<ISessionStore>(provider =>
{
    var factory = provider.GetRequiredService<SessionStoreFactory>();
    return factory.CreateSessionStore();
});

// Register resilience services
builder.Services.AddTransient<ILogger<CircuitBreaker>>(provider => 
    provider.GetRequiredService<ILogger<CircuitBreaker>>());
builder.Services.AddTransient<ILogger<RetryPolicy>>(provider => 
    provider.GetRequiredService<ILogger<RetryPolicy>>());
builder.Services.AddTransient<ILogger<ResilientSessionStore>>(provider => 
    provider.GetRequiredService<ILogger<ResilientSessionStore>>());
builder.Services.AddTransient<ILogger<InMemorySessionStore>>(provider => 
    provider.GetRequiredService<ILogger<InMemorySessionStore>>());

// Register session managers
builder.Services.AddScoped<SessionManager>();
builder.Services.AddScoped<ISessionManager>(provider => provider.GetRequiredService<SessionManager>());

// Add controllers
builder.Services.AddControllers();

// Add Swagger/OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "External Session Web API",
        Version = "v1",
        Description = "A .NET Web API with Windows authentication and external session storage",
        Contact = new Microsoft.OpenApi.Models.OpenApiContact
        {
            Name = "API Support",
            Email = "support@example.com"
        }
    });

    // Include XML comments if available
    var xmlFile = $"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    if (File.Exists(xmlPath))
    {
        c.IncludeXmlComments(xmlPath);
    }

    // Add Windows Authentication scheme
    c.AddSecurityDefinition("windows", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
        Scheme = "negotiate",
        Description = "Windows Authentication"
    });

    c.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "windows"
                }
            },
            new string[] {}
        }
    });
});

// Add services to the container.
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "External Session Web API v1");
        c.RoutePrefix = "swagger";
    });
}

app.UseHttpsRedirection();

// Add global exception handling
app.UseGlobalExceptionHandling();

// Add authentication and authorization middleware
app.UseAuthentication();
app.UseAuthorization();

// Add session management middleware
app.UseSessionManagement();

// Map controllers
app.MapControllers();

app.Run();

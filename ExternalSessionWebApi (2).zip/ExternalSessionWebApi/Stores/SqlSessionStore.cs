using ExternalSessionWebApi.Data;
using ExternalSessionWebApi.Interfaces;
using ExternalSessionWebApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace ExternalSessionWebApi.Stores
{
    public class SqlSessionStore : ISessionStore
    {
        private readonly SessionDbContext _context;
        private readonly ILogger<SqlSessionStore> _logger;

        public SqlSessionStore(SessionDbContext context, ILogger<SqlSessionStore> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<SessionData?> GetAsync(string sessionId)
        {
            try
            {
                var entity = await _context.Sessions
                    .FirstOrDefaultAsync(s => s.SessionId == sessionId);

                if (entity == null || entity.IsExpired)
                {
                    if (entity?.IsExpired == true)
                    {
                        await RemoveAsync(sessionId);
                    }
                    return null;
                }

                return MapToSessionData(entity);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving session {SessionId} from database", sessionId);
                return null;
            }
        }

        public async Task SetAsync(string sessionId, SessionData data, TimeSpan expiration)
        {
            try
            {
                var entity = await _context.Sessions
                    .FirstOrDefaultAsync(s => s.SessionId == sessionId);

                if (entity == null)
                {
                    entity = new SessionEntity
                    {
                        SessionId = sessionId,
                        UserId = data.UserId,
                        DataJson = JsonSerializer.Serialize(data.Data),
                        CreatedAt = data.CreatedAt,
                        LastAccessedAt = data.LastAccessedAt,
                        ExpiresAt = data.ExpiresAt
                    };
                    _context.Sessions.Add(entity);
                }
                else
                {
                    entity.UserId = data.UserId;
                    entity.DataJson = JsonSerializer.Serialize(data.Data);
                    entity.LastAccessedAt = data.LastAccessedAt;
                    entity.ExpiresAt = data.ExpiresAt;
                    _context.Sessions.Update(entity);
                }

                await _context.SaveChangesAsync();
                _logger.LogDebug("Stored session {SessionId} in database", sessionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error storing session {SessionId} in database", sessionId);
                throw;
            }
        }

        public async Task RemoveAsync(string sessionId)
        {
            try
            {
                var entity = await _context.Sessions
                    .FirstOrDefaultAsync(s => s.SessionId == sessionId);

                if (entity != null)
                {
                    _context.Sessions.Remove(entity);
                    await _context.SaveChangesAsync();
                    _logger.LogDebug("Removed session {SessionId} from database", sessionId);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing session {SessionId} from database", sessionId);
                throw;
            }
        }

        public async Task<bool> ExistsAsync(string sessionId)
        {
            try
            {
                return await _context.Sessions
                    .AnyAsync(s => s.SessionId == sessionId && s.ExpiresAt > DateTime.UtcNow);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking existence of session {SessionId} in database", sessionId);
                return false;
            }
        }

        public async Task UpdateLastAccessedAsync(string sessionId)
        {
            try
            {
                var entity = await _context.Sessions
                    .FirstOrDefaultAsync(s => s.SessionId == sessionId);

                if (entity != null && !entity.IsExpired)
                {
                    entity.LastAccessedAt = DateTime.UtcNow;
                    _context.Sessions.Update(entity);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating last accessed time for session {SessionId}", sessionId);
                throw;
            }
        }

        public async Task<IEnumerable<string>> GetExpiredSessionsAsync()
        {
            try
            {
                var expiredSessions = await _context.Sessions
                    .Where(s => s.ExpiresAt <= DateTime.UtcNow)
                    .Select(s => s.SessionId)
                    .ToListAsync();

                return expiredSessions;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving expired sessions from database");
                return Enumerable.Empty<string>();
            }
        }

        public async Task CleanupExpiredSessionsAsync()
        {
            try
            {
                var expiredSessions = await _context.Sessions
                    .Where(s => s.ExpiresAt <= DateTime.UtcNow)
                    .ToListAsync();

                if (expiredSessions.Any())
                {
                    _context.Sessions.RemoveRange(expiredSessions);
                    await _context.SaveChangesAsync();

                    _logger.LogInformation("Cleaned up {Count} expired sessions from database", 
                        expiredSessions.Count);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during database session cleanup");
                throw;
            }
        }

        private SessionData MapToSessionData(SessionEntity entity)
        {
            var data = new Dictionary<string, object>();
            
            if (!string.IsNullOrEmpty(entity.DataJson) && entity.DataJson != "{}")
            {
                try
                {
                    var deserializedData = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(entity.DataJson);
                    if (deserializedData != null)
                    {
                        foreach (var kvp in deserializedData)
                        {
                            data[kvp.Key] = kvp.Value;
                        }
                    }
                }
                catch (JsonException ex)
                {
                    _logger.LogWarning(ex, "Failed to deserialize session data for session {SessionId}", entity.SessionId);
                }
            }

            return new SessionData
            {
                SessionId = entity.SessionId,
                UserId = entity.UserId,
                Data = data,
                CreatedAt = entity.CreatedAt,
                LastAccessedAt = entity.LastAccessedAt,
                ExpiresAt = entity.ExpiresAt
            };
        }
    }
}
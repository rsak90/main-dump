using ExternalSessionWebApi.Interfaces;
using ExternalSessionWebApi.Models;
using ExternalSessionWebApi.Services;

namespace ExternalSessionWebApi.Stores
{
    public class ResilientSessionStore : ISessionStore
    {
        private readonly ISessionStore _primaryStore;
        private readonly ISessionStore _fallbackStore;
        private readonly CircuitBreaker _circuitBreaker;
        private readonly RetryPolicy _retryPolicy;
        private readonly ILogger<ResilientSessionStore> _logger;
        private volatile bool _usingFallback = false;

        public ResilientSessionStore(
            ISessionStore primaryStore,
            ISessionStore fallbackStore,
            CircuitBreaker circuitBreaker,
            RetryPolicy retryPolicy,
            ILogger<ResilientSessionStore> logger)
        {
            _primaryStore = primaryStore;
            _fallbackStore = fallbackStore;
            _circuitBreaker = circuitBreaker;
            _retryPolicy = retryPolicy;
            _logger = logger;
        }

        public bool IsUsingFallback => _usingFallback;

        public async Task<SessionData?> GetAsync(string sessionId)
        {
            try
            {
                return await _circuitBreaker.ExecuteAsync(async () =>
                {
                    return await _retryPolicy.ExecuteAsync(
                        () => _primaryStore.GetAsync(sessionId),
                        RetryPolicy.IsTransientException);
                });
            }
            catch (CircuitBreakerOpenException)
            {
                _logger.LogWarning("Circuit breaker open, using fallback store for GetAsync({SessionId})", sessionId);
                return await UseFallbackAsync(() => _fallbackStore.GetAsync(sessionId));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Primary store failed for GetAsync({SessionId}), using fallback", sessionId);
                return await UseFallbackAsync(() => _fallbackStore.GetAsync(sessionId));
            }
        }

        public async Task SetAsync(string sessionId, SessionData data, TimeSpan expiration)
        {
            try
            {
                await _circuitBreaker.ExecuteAsync(async () =>
                {
                    await _retryPolicy.ExecuteAsync(
                        () => _primaryStore.SetAsync(sessionId, data, expiration),
                        RetryPolicy.IsTransientException);
                });

                // If primary succeeded and we were using fallback, try to sync
                if (_usingFallback)
                {
                    try
                    {
                        await _fallbackStore.SetAsync(sessionId, data, expiration);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Failed to sync session {SessionId} to fallback store", sessionId);
                    }
                }
            }
            catch (CircuitBreakerOpenException)
            {
                _logger.LogWarning("Circuit breaker open, using fallback store for SetAsync({SessionId})", sessionId);
                await UseFallbackAsync(() => _fallbackStore.SetAsync(sessionId, data, expiration));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Primary store failed for SetAsync({SessionId}), using fallback", sessionId);
                await UseFallbackAsync(() => _fallbackStore.SetAsync(sessionId, data, expiration));
            }
        }

        public async Task RemoveAsync(string sessionId)
        {
            try
            {
                await _circuitBreaker.ExecuteAsync(async () =>
                {
                    await _retryPolicy.ExecuteAsync(
                        () => _primaryStore.RemoveAsync(sessionId),
                        RetryPolicy.IsTransientException);
                });

                // Also remove from fallback if we were using it
                if (_usingFallback)
                {
                    try
                    {
                        await _fallbackStore.RemoveAsync(sessionId);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Failed to remove session {SessionId} from fallback store", sessionId);
                    }
                }
            }
            catch (CircuitBreakerOpenException)
            {
                _logger.LogWarning("Circuit breaker open, using fallback store for RemoveAsync({SessionId})", sessionId);
                await UseFallbackAsync(() => _fallbackStore.RemoveAsync(sessionId));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Primary store failed for RemoveAsync({SessionId}), using fallback", sessionId);
                await UseFallbackAsync(() => _fallbackStore.RemoveAsync(sessionId));
            }
        }

        public async Task<bool> ExistsAsync(string sessionId)
        {
            try
            {
                return await _circuitBreaker.ExecuteAsync(async () =>
                {
                    return await _retryPolicy.ExecuteAsync(
                        () => _primaryStore.ExistsAsync(sessionId),
                        RetryPolicy.IsTransientException);
                });
            }
            catch (CircuitBreakerOpenException)
            {
                _logger.LogWarning("Circuit breaker open, using fallback store for ExistsAsync({SessionId})", sessionId);
                return await UseFallbackAsync(() => _fallbackStore.ExistsAsync(sessionId));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Primary store failed for ExistsAsync({SessionId}), using fallback", sessionId);
                return await UseFallbackAsync(() => _fallbackStore.ExistsAsync(sessionId));
            }
        }

        public async Task UpdateLastAccessedAsync(string sessionId)
        {
            try
            {
                await _circuitBreaker.ExecuteAsync(async () =>
                {
                    await _retryPolicy.ExecuteAsync(
                        () => _primaryStore.UpdateLastAccessedAsync(sessionId),
                        RetryPolicy.IsTransientException);
                });

                // Also update fallback if we were using it
                if (_usingFallback)
                {
                    try
                    {
                        await _fallbackStore.UpdateLastAccessedAsync(sessionId);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Failed to update last accessed for session {SessionId} in fallback store", sessionId);
                    }
                }
            }
            catch (CircuitBreakerOpenException)
            {
                _logger.LogWarning("Circuit breaker open, using fallback store for UpdateLastAccessedAsync({SessionId})", sessionId);
                await UseFallbackAsync(() => _fallbackStore.UpdateLastAccessedAsync(sessionId));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Primary store failed for UpdateLastAccessedAsync({SessionId}), using fallback", sessionId);
                await UseFallbackAsync(() => _fallbackStore.UpdateLastAccessedAsync(sessionId));
            }
        }

        public async Task<IEnumerable<string>> GetExpiredSessionsAsync()
        {
            try
            {
                return await _circuitBreaker.ExecuteAsync(async () =>
                {
                    return await _retryPolicy.ExecuteAsync(
                        () => _primaryStore.GetExpiredSessionsAsync(),
                        RetryPolicy.IsTransientException);
                });
            }
            catch (CircuitBreakerOpenException)
            {
                _logger.LogWarning("Circuit breaker open, using fallback store for GetExpiredSessionsAsync");
                return await UseFallbackAsync(() => _fallbackStore.GetExpiredSessionsAsync());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Primary store failed for GetExpiredSessionsAsync, using fallback");
                return await UseFallbackAsync(() => _fallbackStore.GetExpiredSessionsAsync());
            }
        }

        public async Task CleanupExpiredSessionsAsync()
        {
            // Try to cleanup both stores
            var primaryTask = CleanupPrimaryStoreAsync();
            var fallbackTask = CleanupFallbackStoreAsync();

            await Task.WhenAll(primaryTask, fallbackTask);
        }

        private async Task CleanupPrimaryStoreAsync()
        {
            try
            {
                await _circuitBreaker.ExecuteAsync(async () =>
                {
                    await _retryPolicy.ExecuteAsync(
                        () => _primaryStore.CleanupExpiredSessionsAsync(),
                        RetryPolicy.IsTransientException);
                });
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to cleanup expired sessions in primary store");
            }
        }

        private async Task CleanupFallbackStoreAsync()
        {
            try
            {
                await _fallbackStore.CleanupExpiredSessionsAsync();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to cleanup expired sessions in fallback store");
            }
        }

        private async Task<T> UseFallbackAsync<T>(Func<Task<T>> fallbackOperation)
        {
            if (!_usingFallback)
            {
                _usingFallback = true;
                _logger.LogWarning("Switching to fallback session store");
            }

            return await fallbackOperation();
        }

        private async Task UseFallbackAsync(Func<Task> fallbackOperation)
        {
            if (!_usingFallback)
            {
                _usingFallback = true;
                _logger.LogWarning("Switching to fallback session store");
            }

            await fallbackOperation();
        }
    }
}
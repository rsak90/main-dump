using ExternalSessionWebApi.Interfaces;
using ExternalSessionWebApi.Models;
using StackExchange.Redis;
using System.Text.Json;

namespace ExternalSessionWebApi.Stores
{
    public class RedisSessionStore : ISessionStore
    {
        private readonly IDatabase _database;
        private readonly ILogger<RedisSessionStore> _logger;
        private const string SessionKeyPrefix = "session:";
        private const string ExpirationSetKey = "session:expirations";

        public RedisSessionStore(IConnectionMultiplexer redis, ILogger<RedisSessionStore> logger)
        {
            _database = redis.GetDatabase();
            _logger = logger;
        }

        public async Task<SessionData?> GetAsync(string sessionId)
        {
            try
            {
                var key = GetSessionKey(sessionId);
                var value = await _database.StringGetAsync(key);
                
                if (!value.HasValue)
                {
                    return null;
                }

                var sessionData = JsonSerializer.Deserialize<SessionData>(value!);
                
                if (sessionData?.IsExpired == true)
                {
                    await RemoveAsync(sessionId);
                    return null;
                }

                return sessionData;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving session {SessionId} from Redis", sessionId);
                return null;
            }
        }

        public async Task SetAsync(string sessionId, SessionData data, TimeSpan expiration)
        {
            try
            {
                var key = GetSessionKey(sessionId);
                var value = JsonSerializer.Serialize(data);
                
                await _database.StringSetAsync(key, value, expiration);
                
                // Add to expiration tracking set
                var expirationScore = DateTimeOffset.UtcNow.Add(expiration).ToUnixTimeSeconds();
                await _database.SortedSetAddAsync(ExpirationSetKey, sessionId, expirationScore);

                _logger.LogDebug("Stored session {SessionId} in Redis with expiration {Expiration}", 
                    sessionId, expiration);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error storing session {SessionId} in Redis", sessionId);
                throw;
            }
        }

        public async Task RemoveAsync(string sessionId)
        {
            try
            {
                var key = GetSessionKey(sessionId);
                await _database.KeyDeleteAsync(key);
                await _database.SortedSetRemoveAsync(ExpirationSetKey, sessionId);

                _logger.LogDebug("Removed session {SessionId} from Redis", sessionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing session {SessionId} from Redis", sessionId);
                throw;
            }
        }

        public async Task<bool> ExistsAsync(string sessionId)
        {
            try
            {
                var key = GetSessionKey(sessionId);
                return await _database.KeyExistsAsync(key);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking existence of session {SessionId} in Redis", sessionId);
                return false;
            }
        }

        public async Task UpdateLastAccessedAsync(string sessionId)
        {
            try
            {
                var sessionData = await GetAsync(sessionId);
                if (sessionData != null)
                {
                    sessionData.LastAccessedAt = DateTime.UtcNow;
                    var key = GetSessionKey(sessionId);
                    var value = JsonSerializer.Serialize(sessionData);
                    
                    // Update without changing expiration
                    var ttl = await _database.KeyTimeToLiveAsync(key);
                    if (ttl.HasValue)
                    {
                        await _database.StringSetAsync(key, value, ttl.Value);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating last accessed time for session {SessionId}", sessionId);
                throw;
            }
        }

        public async Task<IEnumerable<string>> GetExpiredSessionsAsync()
        {
            try
            {
                var currentTime = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                var expiredSessions = await _database.SortedSetRangeByScoreAsync(
                    ExpirationSetKey, 
                    0, 
                    currentTime);

                return expiredSessions.Select(s => s.ToString());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving expired sessions from Redis");
                return Enumerable.Empty<string>();
            }
        }

        public async Task CleanupExpiredSessionsAsync()
        {
            try
            {
                var expiredSessions = await GetExpiredSessionsAsync();
                var tasks = expiredSessions.Select(RemoveAsync);
                await Task.WhenAll(tasks);

                if (expiredSessions.Any())
                {
                    _logger.LogInformation("Cleaned up {Count} expired sessions from Redis", 
                        expiredSessions.Count());
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during Redis session cleanup");
                throw;
            }
        }

        private string GetSessionKey(string sessionId)
        {
            return $"{SessionKeyPrefix}{sessionId}";
        }
    }
}
using ExternalSessionWebApi.Interfaces;
using ExternalSessionWebApi.Models;
using System.Collections.Concurrent;

namespace ExternalSessionWebApi.Stores
{
    public class InMemorySessionStore : ISessionStore
    {
        private readonly ConcurrentDictionary<string, SessionData> _sessions;
        private readonly ILogger<InMemorySessionStore> _logger;
        private readonly Timer _cleanupTimer;

        public InMemorySessionStore(ILogger<InMemorySessionStore> logger)
        {
            _sessions = new ConcurrentDictionary<string, SessionData>();
            _logger = logger;
            
            // Run cleanup every 5 minutes
            _cleanupTimer = new Timer(async _ => await CleanupExpiredSessionsAsync(), 
                null, TimeSpan.FromMinutes(5), TimeSpan.FromMinutes(5));
        }

        public Task<SessionData?> GetAsync(string sessionId)
        {
            try
            {
                if (_sessions.TryGetValue(sessionId, out var sessionData))
                {
                    if (sessionData.IsExpired)
                    {
                        _sessions.TryRemove(sessionId, out _);
                        return Task.FromResult<SessionData?>(null);
                    }
                    return Task.FromResult<SessionData?>(sessionData);
                }
                return Task.FromResult<SessionData?>(null);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving session {SessionId} from in-memory store", sessionId);
                return Task.FromResult<SessionData?>(null);
            }
        }

        public Task SetAsync(string sessionId, SessionData data, TimeSpan expiration)
        {
            try
            {
                // Create a copy to avoid reference issues
                var sessionCopy = new SessionData
                {
                    SessionId = data.SessionId,
                    UserId = data.UserId,
                    Data = new Dictionary<string, object>(data.Data),
                    CreatedAt = data.CreatedAt,
                    LastAccessedAt = data.LastAccessedAt,
                    ExpiresAt = DateTime.UtcNow.Add(expiration)
                };

                _sessions.AddOrUpdate(sessionId, sessionCopy, (key, existing) => sessionCopy);
                
                _logger.LogDebug("Stored session {SessionId} in in-memory store with expiration {Expiration}", 
                    sessionId, expiration);
                
                return Task.CompletedTask;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error storing session {SessionId} in in-memory store", sessionId);
                throw;
            }
        }

        public Task RemoveAsync(string sessionId)
        {
            try
            {
                _sessions.TryRemove(sessionId, out _);
                _logger.LogDebug("Removed session {SessionId} from in-memory store", sessionId);
                return Task.CompletedTask;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing session {SessionId} from in-memory store", sessionId);
                throw;
            }
        }

        public Task<bool> ExistsAsync(string sessionId)
        {
            try
            {
                if (_sessions.TryGetValue(sessionId, out var sessionData))
                {
                    if (sessionData.IsExpired)
                    {
                        _sessions.TryRemove(sessionId, out _);
                        return Task.FromResult(false);
                    }
                    return Task.FromResult(true);
                }
                return Task.FromResult(false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking existence of session {SessionId} in in-memory store", sessionId);
                return Task.FromResult(false);
            }
        }

        public Task UpdateLastAccessedAsync(string sessionId)
        {
            try
            {
                if (_sessions.TryGetValue(sessionId, out var sessionData) && !sessionData.IsExpired)
                {
                    sessionData.LastAccessedAt = DateTime.UtcNow;
                }
                return Task.CompletedTask;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating last accessed time for session {SessionId}", sessionId);
                throw;
            }
        }

        public Task<IEnumerable<string>> GetExpiredSessionsAsync()
        {
            try
            {
                var expiredSessions = _sessions
                    .Where(kvp => kvp.Value.IsExpired)
                    .Select(kvp => kvp.Key)
                    .ToList();

                return Task.FromResult<IEnumerable<string>>(expiredSessions);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving expired sessions from in-memory store");
                return Task.FromResult<IEnumerable<string>>(Enumerable.Empty<string>());
            }
        }

        public Task CleanupExpiredSessionsAsync()
        {
            try
            {
                var expiredKeys = _sessions
                    .Where(kvp => kvp.Value.IsExpired)
                    .Select(kvp => kvp.Key)
                    .ToList();

                foreach (var key in expiredKeys)
                {
                    _sessions.TryRemove(key, out _);
                }

                if (expiredKeys.Any())
                {
                    _logger.LogInformation("Cleaned up {Count} expired sessions from in-memory store", 
                        expiredKeys.Count);
                }

                return Task.CompletedTask;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during in-memory session cleanup");
                throw;
            }
        }

        public void Dispose()
        {
            _cleanupTimer?.Dispose();
        }
    }
}
# Deployment Guide

This guide covers deploying the External Session Web API to various Windows environments with different session storage providers.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Development Environment Setup](#development-environment-setup)
3. [Production Deployment](#production-deployment)
4. [Storage Provider Setup](#storage-provider-setup)
5. [IIS Configuration](#iis-configuration)
6. [Performance Tuning](#performance-tuning)
7. [Monitoring and Maintenance](#monitoring-and-maintenance)
8. [Troubleshooting](#troubleshooting)

## Prerequisites

### System Requirements

- **Operating System**: Windows Server 2019 or later, Windows 10/11
- **.NET Runtime**: .NET 9.0 Runtime
- **IIS**: Internet Information Services with Windows Authentication
- **Memory**: Minimum 4GB RAM (8GB+ recommended for 700+ users)
- **Storage**: 10GB+ free disk space

### External Dependencies

Choose one or more based on your session storage needs:

- **Redis**: Redis for Windows or Redis on WSL2
- **SQL Server**: SQL Server 2019+ or SQL Server Express
- **PostgreSQL**: PostgreSQL 13+ for Windows
- **SQLite**: No additional setup required (embedded)

## Development Environment Setup

### 1. Install Prerequisites

```powershell
# Install .NET 9.0 SDK
winget install Microsoft.DotNet.SDK.9

# Install Redis (optional)
# Download from: https://github.com/microsoftarchive/redis/releases
# Or use Docker Desktop with WSL2
```

### 2. Clone and Build

```powershell
git clone <repository-url>
cd ExternalSessionWebApi
dotnet restore
dotnet build
```

### 3. Configure Development Settings

Update `appsettings.Development.json`:

```json
{
  "SessionConfiguration": {
    "Provider": "SQLite",
    "ConnectionString": "Data Source=sessions.db",
    "DefaultExpiration": "24:00:00"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Debug",
      "Microsoft.AspNetCore": "Information"
    }
  }
}
```

### 4. Run Development Server

```powershell
dotnet run
# Navigate to https://localhost:5001/swagger
```

## Production Deployment

### Option 1: IIS Deployment

#### 1. Publish Application

```powershell
dotnet publish -c Release -o C:\inetpub\wwwroot\ExternalSessionWebApi
```

#### 2. Create IIS Application

```powershell
# Run as Administrator
Import-Module WebAdministration

# Create Application Pool
New-WebAppPool -Name "ExternalSessionWebApiPool"
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name processModel.identityType -Value ApplicationPoolIdentity
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name recycling.periodicRestart.time -Value "00:00:00"

# Create Website
New-Website -Name "ExternalSessionWebApi" -Port 80 -PhysicalPath "C:\inetpub\wwwroot\ExternalSessionWebApi" -ApplicationPool "ExternalSessionWebApiPool"

# Enable Windows Authentication
Set-WebConfigurationProperty -Filter "/system.webServer/security/authentication/windowsAuthentication" -Name enabled -Value $true -PSPath "IIS:" -Location "ExternalSessionWebApi"
Set-WebConfigurationProperty -Filter "/system.webServer/security/authentication/anonymousAuthentication" -Name enabled -Value $false -PSPath "IIS:" -Location "ExternalSessionWebApi"
```

### Option 2: Windows Service Deployment

#### 1. Install as Windows Service

```powershell
# Publish as self-contained
dotnet publish -c Release -r win-x64 --self-contained -o C:\Services\ExternalSessionWebApi

# Install service
sc create "ExternalSessionWebApi" binPath="C:\Services\ExternalSessionWebApi\ExternalSessionWebApi.exe" start=auto
sc description "ExternalSessionWebApi" "External Session Web API Service"
sc start "ExternalSessionWebApi"
```

#### 2. Configure Service Settings

Create `appsettings.Production.json`:

```json
{
  "Urls": "http://localhost:5000;https://localhost:5001",
  "SessionConfiguration": {
    "Provider": "Redis",
    "ConnectionString": "localhost:6379",
    "DefaultExpiration": "24:00:00",
    "CleanupIntervalMinutes": 30
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
```

## Storage Provider Setup

### Redis Setup

#### Option 1: Redis for Windows (Legacy)

```powershell
# Download from GitHub releases
# https://github.com/microsoftarchive/redis/releases

# Install and start service
redis-server.exe --service-install
redis-server.exe --service-start

# Test connection
redis-cli ping
```

#### Option 2: Redis on WSL2 (Recommended)

```powershell
# Install WSL2 and Ubuntu
wsl --install -d Ubuntu

# In WSL2 terminal:
sudo apt update
sudo apt install redis-server
sudo service redis-server start

# Configure Redis
sudo nano /etc/redis/redis.conf
# Set: bind 0.0.0.0
# Set: protected-mode no (for development only)

sudo service redis-server restart
```

#### Configuration

```json
{
  "SessionConfiguration": {
    "Provider": "Redis",
    "ConnectionString": "localhost:6379",
    "ProviderOptions": {
      "AbortOnConnectFail": "false",
      "ConnectRetry": "3",
      "ConnectTimeout": "5000",
      "SyncTimeout": "5000"
    }
  }
}
```

### SQL Server Setup

#### 1. Install SQL Server

```powershell
# Download SQL Server Express
# https://www.microsoft.com/en-us/sql-server/sql-server-downloads

# Or use existing SQL Server instance
```

#### 2. Create Database

```sql
CREATE DATABASE SessionStore;
GO

USE SessionStore;
GO

-- Create login for application (optional)
CREATE LOGIN [ExternalSessionWebApiUser] WITH PASSWORD = 'YourSecurePassword123!';
CREATE USER [ExternalSessionWebApiUser] FOR LOGIN [ExternalSessionWebApiUser];
ALTER ROLE db_datareader ADD MEMBER [ExternalSessionWebApiUser];
ALTER ROLE db_datawriter ADD MEMBER [ExternalSessionWebApiUser];
ALTER ROLE db_ddladmin ADD MEMBER [ExternalSessionWebApiUser];
```

#### 3. Run Migrations

```powershell
cd C:\inetpub\wwwroot\ExternalSessionWebApi
dotnet ef database update
```

#### Configuration

```json
{
  "SessionConfiguration": {
    "Provider": "SqlServer",
    "ConnectionString": "Server=localhost;Database=SessionStore;Integrated Security=true;TrustServerCertificate=true;"
  }
}
```

### PostgreSQL Setup

#### 1. Install PostgreSQL

```powershell
# Download from https://www.postgresql.org/download/windows/
# Or use Chocolatey
choco install postgresql
```

#### 2. Create Database

```sql
CREATE DATABASE sessionstore;
CREATE USER sessionapi WITH PASSWORD 'YourSecurePassword123!';
GRANT ALL PRIVILEGES ON DATABASE sessionstore TO sessionapi;
```

#### Configuration

```json
{
  "SessionConfiguration": {
    "Provider": "PostgreSQL",
    "ConnectionString": "Host=localhost;Database=sessionstore;Username=sessionapi;Password=YourSecurePassword123!;"
  }
}
```

## IIS Configuration

### 1. Enable Required Features

```powershell
# Run as Administrator
Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerRole, IIS-WebServer, IIS-CommonHttpFeatures, IIS-HttpErrors, IIS-HttpLogging, IIS-RequestFiltering, IIS-StaticContent, IIS-Security, IIS-WindowsAuthentication, IIS-NetFxExtensibility45, IIS-ISAPIExtensions, IIS-ISAPIFilter, IIS-ASPNET45
```

### 2. Install ASP.NET Core Hosting Bundle

```powershell
# Download and install from:
# https://dotnet.microsoft.com/en-us/download/dotnet/9.0
# Look for "ASP.NET Core Runtime" -> "Hosting Bundle"
```

### 3. Configure Application Pool

```powershell
Import-Module WebAdministration

# Set .NET CLR Version to "No Managed Code"
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name managedRuntimeVersion -Value ""

# Set Process Model
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name processModel.identityType -Value ApplicationPoolIdentity
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name processModel.loadUserProfile -Value $true

# Set Recycling Conditions
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name recycling.periodicRestart.time -Value "00:00:00"
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name recycling.periodicRestart.memory -Value 1048576  # 1GB

# Set Failure Settings
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name failure.rapidFailProtection -Value $true
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name failure.rapidFailProtectionMaxCrashes -Value 5
```

### 4. Configure Authentication

```xml
<!-- web.config -->
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <location path="." inheritInChildApplications="false">
    <system.webServer>
      <security>
        <authentication>
          <windowsAuthentication enabled="true" />
          <anonymousAuthentication enabled="false" />
        </authentication>
      </security>
      <handlers>
        <add name="aspNetCore" path="*" verb="*" modules="AspNetCoreModuleV2" resourceType="Unspecified" />
      </handlers>
      <aspNetCore processPath="dotnet" arguments=".\ExternalSessionWebApi.dll" stdoutLogEnabled="false" stdoutLogFile=".\logs\stdout" hostingModel="inprocess" />
    </system.webServer>
  </location>
</configuration>
```

## Performance Tuning

### For 700+ Concurrent Users

#### 1. Application Pool Settings

```powershell
# Increase worker process limits
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name processModel.maxProcesses -Value 4

# Set CPU limits
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name cpu.limit -Value 0  # No limit
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name cpu.action -Value NoAction

# Memory settings
Set-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name recycling.periodicRestart.memory -Value 2097152  # 2GB
```

#### 2. Connection Pool Settings

For SQL Server:

```json
{
  "SessionConfiguration": {
    "ConnectionString": "Server=localhost;Database=SessionStore;Integrated Security=true;TrustServerCertificate=true;Max Pool Size=100;Min Pool Size=10;Connection Timeout=30;"
  }
}
```

For Redis:

```json
{
  "SessionConfiguration": {
    "ProviderOptions": {
      "ConnectRetry": "3",
      "ConnectTimeout": "5000",
      "SyncTimeout": "5000",
      "AsyncTimeout": "5000"
    }
  }
}
```

#### 3. Garbage Collection Settings

Add to `ExternalSessionWebApi.runtimeconfig.json`:

```json
{
  "runtimeOptions": {
    "configProperties": {
      "System.GC.Server": true,
      "System.GC.Concurrent": true,
      "System.GC.RetainVM": true
    }
  }
}
```

#### 4. Session Cleanup Configuration

```json
{
  "SessionConfiguration": {
    "CleanupIntervalMinutes": 15,
    "DefaultExpiration": "02:00:00"
  }
}
```

## Monitoring and Maintenance

### 1. Health Checks

Configure health check endpoints:

```http
GET /api/diagnostics/health
GET /api/diagnostics/session-stats
GET /api/diagnostics/system-info
```

### 2. Logging Configuration

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning",
      "ExternalSessionWebApi": "Debug"
    },
    "EventLog": {
      "LogLevel": {
        "Default": "Warning"
      }
    }
  }
}
```

### 3. Performance Counters

Monitor these Windows Performance Counters:

- **ASP.NET Core Apps**: Requests/sec, Request Duration
- **Process**: Working Set, CPU Usage
- **SQL Server**: Connections, Batch Requests/sec (if using SQL)

### 4. Automated Maintenance

Create a PowerShell script for maintenance:

```powershell
# maintenance.ps1
$apiUrl = "https://localhost:5001/api/diagnostics"

# Cleanup expired sessions
Invoke-RestMethod -Uri "$apiUrl/cleanup-sessions" -Method POST -UseDefaultCredentials

# Check health
$health = Invoke-RestMethod -Uri "$apiUrl/health" -UseDefaultCredentials
Write-Host "Health Status: $($health.data.Status)"

# Log session statistics
$stats = Invoke-RestMethod -Uri "$apiUrl/session-stats" -UseDefaultCredentials
Write-Host "Expired Sessions: $($stats.data.ExpiredSessionsCount)"
```

Schedule this script to run every hour:

```powershell
$action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-File C:\Scripts\maintenance.ps1"
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Hours 1)
Register-ScheduledTask -TaskName "ExternalSessionWebApi-Maintenance" -Action $action -Trigger $trigger
```

## Troubleshooting

### Common Issues

#### 1. Windows Authentication Not Working

**Symptoms**: 401 Unauthorized errors

**Solutions**:
```powershell
# Check IIS authentication settings
Get-WebConfigurationProperty -Filter "/system.webServer/security/authentication/windowsAuthentication" -Name enabled -PSPath "IIS:" -Location "ExternalSessionWebApi"

# Enable Windows Authentication
Set-WebConfigurationProperty -Filter "/system.webServer/security/authentication/windowsAuthentication" -Name enabled -Value $true -PSPath "IIS:" -Location "ExternalSessionWebApi"

# Check application pool identity
Get-ItemProperty -Path "IIS:\AppPools\ExternalSessionWebApiPool" -Name processModel.identityType
```

#### 2. Session Store Connection Issues

**Redis Connection Failures**:
```powershell
# Test Redis connectivity
redis-cli -h localhost -p 6379 ping

# Check Windows Firewall
New-NetFirewallRule -DisplayName "Redis" -Direction Inbound -Protocol TCP -LocalPort 6379 -Action Allow
```

**SQL Server Connection Issues**:
```powershell
# Test SQL connection
sqlcmd -S localhost -E -Q "SELECT @@VERSION"

# Check SQL Server service
Get-Service -Name "MSSQLSERVER"
Start-Service -Name "MSSQLSERVER"
```

#### 3. High Memory Usage

**Solutions**:
```powershell
# Reduce session expiration time
# Update appsettings.json: "DefaultExpiration": "01:00:00"

# Increase cleanup frequency
# Update appsettings.json: "CleanupIntervalMinutes": 10

# Monitor memory usage
Get-Counter "\Process(w3wp)\Working Set"
```

#### 4. Performance Issues

**Diagnostics**:
```powershell
# Check application pool recycling
Get-EventLog -LogName System -Source "Microsoft-Windows-WAS" -Newest 10

# Monitor request duration
# Use Application Insights or custom logging

# Check database performance (SQL Server)
# Monitor wait stats and blocking queries
```

### Log Analysis

Common log patterns to monitor:

```
# Successful session operations
[INFO] Created new session {SessionId} for user {UserId}
[INFO] Session {SessionId} refreshed successfully

# Circuit breaker events
[WARN] Circuit breaker opening - primary session store has failed 5 times
[INFO] Circuit breaker closing - primary session store is healthy

# Performance issues
[WARN] Session operation took longer than expected: {Duration}ms
[ERROR] Session store connection timeout
```

### Emergency Procedures

#### 1. Fallback to In-Memory Sessions

If external storage fails completely:

1. The circuit breaker will automatically activate
2. Sessions will be stored in memory
3. Monitor application memory usage
4. Restart application pools if memory usage is high

#### 2. Database Recovery

For SQL-based providers:

```sql
-- Check session table integrity
DBCC CHECKDB('SessionStore');

-- Rebuild indexes if needed
ALTER INDEX ALL ON Sessions REBUILD;

-- Clean up old sessions manually
DELETE FROM Sessions WHERE ExpiresAt < GETUTCDATE();
```

#### 3. Redis Recovery

```powershell
# Restart Redis service
Restart-Service Redis

# Clear all sessions if needed (emergency only)
redis-cli FLUSHDB
```

This deployment guide provides comprehensive instructions for setting up and maintaining the External Session Web API in production environments. Follow the performance tuning recommendations for optimal performance with 700+ concurrent users.
using ExternalSessionWebApi.Models;

namespace ExternalSessionWebApi.Interfaces
{
    public interface ISessionStore
    {
        Task<SessionData?> GetAsync(string sessionId);
        Task SetAsync(string sessionId, SessionData data, TimeSpan expiration);
        Task RemoveAsync(string sessionId);
        Task<bool> ExistsAsync(string sessionId);
        Task UpdateLastAccessedAsync(string sessionId);
        Task<IEnumerable<string>> GetExpiredSessionsAsync();
        Task CleanupExpiredSessionsAsync();
    }
}
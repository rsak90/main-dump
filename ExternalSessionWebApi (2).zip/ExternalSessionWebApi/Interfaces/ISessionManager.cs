using ExternalSessionWebApi.Models;

namespace ExternalSessionWebApi.Interfaces
{
    public interface ISessionManager
    {
        Task<SessionContext> GetOrCreateSessionAsync(string userId);
        Task UpdateSessionAsync(string sessionId, object data);
        Task<T?> GetSessionDataAsync<T>(string sessionId, string key);
        Task SetSessionDataAsync(string sessionId, string key, object value);
        Task InvalidateSessionAsync(string sessionId);
        Task<bool> IsSessionValidAsync(string sessionId);
        Task RefreshSessionAsync(string sessionId);
    }
}
using System.Security.Principal;

namespace ExternalSessionWebApi.Interfaces
{
    public interface IWindowsAuthenticationService
    {
        Task<WindowsIdentity?> ValidateWindowsCredentialsAsync(string username);
        string ExtractUserIdentity(WindowsIdentity identity);
        string ExtractDomainName(WindowsIdentity identity);
        bool IsUserAuthenticated(WindowsIdentity? identity);
    }
}
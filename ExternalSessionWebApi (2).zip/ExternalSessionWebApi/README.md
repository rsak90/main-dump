# External Session Web API

A .NET Web API that uses Windows authentication for user identification while storing session data in external data stores (Redis, SQL Server, PostgreSQL, SQLite) instead of relying on IIS application pool session management.

## Features

- **Windows Authentication**: Seamless integration with Windows credentials
- **Multiple Storage Backends**: Support for Redis, SQL Server, PostgreSQL, and SQLite
- **Resilient Architecture**: Circuit breaker pattern with fallback to in-memory sessions
- **Comprehensive Logging**: Structured logging with request tracking
- **Error Handling**: Global exception handling with proper HTTP status codes
- **Session Management**: Automatic session creation, expiration, and cleanup
- **API Documentation**: Swagger/OpenAPI documentation

## Supported Storage Providers

### Redis (Recommended for 700+ users)
- Sub-millisecond performance
- Built-in expiration
- Horizontal scaling capabilities

### PostgreSQL
- Open source database
- Excellent JSON support
- Great performance for session storage

### SQL Server
- Enterprise-grade database
- Native Windows integration
- Familiar tooling

### SQLite
- No external dependencies
- Perfect for development
- Suitable for smaller deployments

## Configuration

### appsettings.json

```json
{
  "SessionConfiguration": {
    "Provider": "SQLite",
    "ConnectionString": "Data Source=sessions.db",
    "DefaultExpiration": "24:00:00",
    "EnableDistributedLocking": false,
    "CleanupIntervalMinutes": 60,
    "EnableHealthChecks": true,
    "ProviderOptions": {}
  }
}
```

### Redis Configuration (appsettings.Development.json)

```json
{
  "SessionConfiguration": {
    "Provider": "Redis",
    "ConnectionString": "localhost:6379",
    "DefaultExpiration": "24:00:00",
    "EnableDistributedLocking": false,
    "CleanupIntervalMinutes": 60,
    "EnableHealthChecks": true,
    "ProviderOptions": {
      "AbortOnConnectFail": "false",
      "ConnectRetry": "3"
    }
  }
}
```

### SQL Server Configuration

```json
{
  "SessionConfiguration": {
    "Provider": "SqlServer",
    "ConnectionString": "Server=localhost;Database=SessionStore;Integrated Security=true;TrustServerCertificate=true;",
    "DefaultExpiration": "24:00:00"
  }
}
```

### PostgreSQL Configuration

```json
{
  "SessionConfiguration": {
    "Provider": "PostgreSQL",
    "ConnectionString": "Host=localhost;Database=sessionstore;Username=postgres;Password=password;",
    "DefaultExpiration": "24:00:00"
  }
}
```

## API Endpoints

### Authentication & Session Management

#### Get User Information
```http
GET /api/sample/user-info
```

Returns current user information and session details.

**Response:**
```json
{
  "success": true,
  "message": "User information retrieved successfully",
  "data": {
    "userId": "john.doe",
    "userName": "john.doe",
    "domain": "CONTOSO",
    "sessionId": "abc123...",
    "sessionCreated": "2024-10-28T10:00:00Z",
    "lastAccessed": "2024-10-28T10:30:00Z",
    "isAuthenticated": true
  },
  "timestamp": "2024-10-28T10:30:00Z"
}
```

### Session Data Management

#### Store Session Data
```http
POST /api/sample/session-data/{key}
Content-Type: application/json

{
  "value": "any JSON value"
}
```

#### Retrieve Session Data
```http
GET /api/sample/session-data/{key}
```

#### Store Multiple Session Data Items
```http
POST /api/sample/session-data
Content-Type: application/json

{
  "key1": "value1",
  "key2": { "nested": "object" },
  "key3": [1, 2, 3]
}
```

#### Get All Session Data
```http
GET /api/sample/session-data
```

### Session Lifecycle

#### Refresh Session
```http
POST /api/sample/session/refresh
```

Extends the session expiration time.

#### Clear Session
```http
DELETE /api/sample/session
```

Invalidates the current user's session.

### Example: Counter Functionality

#### Increment Counter
```http
POST /api/sample/counter/increment
```

#### Get Counter Value
```http
GET /api/sample/counter
```

#### Reset Counter
```http
DELETE /api/sample/counter
```

### Diagnostics & Monitoring

#### Health Check
```http
GET /api/diagnostics/health
```

#### Session Statistics
```http
GET /api/diagnostics/session-stats
```

#### System Information
```http
GET /api/diagnostics/system-info
```

#### Cleanup Expired Sessions
```http
POST /api/diagnostics/cleanup-sessions
```

## Running the Application

### Prerequisites

1. .NET 9.0 SDK
2. Windows environment (for Windows Authentication)
3. Optional: Redis server (if using Redis provider)
4. Optional: SQL Server/PostgreSQL (if using database providers)

### Development

1. Clone the repository
2. Navigate to the project directory
3. Run the application:

```bash
dotnet run
```

4. Open browser to `https://localhost:5001/swagger` to view API documentation

### Database Setup

For SQL-based providers, run migrations to create the session table:

```bash
dotnet ef database update
```

### Production Deployment

1. Configure the appropriate session provider in `appsettings.json`
2. Set up the external storage system (Redis/Database)
3. Configure IIS with Windows Authentication enabled
4. Deploy the application

## Architecture

### Circuit Breaker Pattern

The application implements a circuit breaker pattern that:
- Monitors failures to the primary session store
- Opens the circuit after 5 consecutive failures
- Falls back to in-memory session storage
- Automatically attempts to close the circuit after 2 minutes

### Resilience Features

- **Fallback Storage**: In-memory session storage when primary store fails
- **Retry Logic**: Automatic retry for transient failures
- **Health Monitoring**: Built-in health checks for session stores
- **Graceful Degradation**: Application continues to function even if external storage fails

### Security

- **Windows Authentication**: Integrated Windows authentication
- **Session Security**: Cryptographically secure session IDs
- **Data Protection**: Session data encryption in transit
- **Access Control**: User-specific session isolation

## Performance Considerations

### For 700+ Concurrent Users

1. **Use Redis**: Best performance for high-concurrency scenarios
2. **Connection Pooling**: Configured automatically for all providers
3. **Session Cleanup**: Automatic cleanup of expired sessions
4. **Circuit Breaker**: Prevents cascading failures
5. **Logging**: Structured logging for performance monitoring

### Monitoring

- Request/response logging with timing
- Session operation metrics
- Error tracking and alerting
- Health check endpoints

## Troubleshooting

### Common Issues

1. **Windows Authentication Not Working**
   - Ensure IIS has Windows Authentication enabled
   - Check that the application pool identity has appropriate permissions

2. **Redis Connection Failures**
   - Verify Redis server is running
   - Check connection string format
   - Ensure firewall allows connections

3. **Database Connection Issues**
   - Verify connection string
   - Ensure database exists and migrations are applied
   - Check SQL Server/PostgreSQL service status

### Logging

The application provides comprehensive logging:
- Request/response details
- Session operations
- Error conditions
- Performance metrics

Check the console output or configure file logging for detailed diagnostics.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.
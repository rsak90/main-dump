using ExternalSessionWebApi.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ExternalSessionWebApi.Controllers
{
    [Route("api/[controller]")]
    public class SampleController : BaseApiController
    {
        public SampleController(
            ISessionManager sessionManager,
            IWindowsAuthenticationService authService,
            ILogger<SampleController> logger)
            : base(sessionManager, authService, logger)
        {
        }

        /// <summary>
        /// Get current user information and session details
        /// </summary>
        [HttpGet("user-info")]
        public async Task<IActionResult> GetUserInfo()
        {
            try
            {
                var session = await GetCurrentSessionAsync();
                if (session == null)
                {
                    return Unauthorized(new { error = "Unable to create or retrieve session" });
                }

                var userInfo = new
                {
                    UserId = GetCurrentUserId(),
                    UserName = session.UserName,
                    Domain = GetCurrentUserDomain(),
                    SessionId = session.SessionId,
                    SessionCreated = session.CreatedAt,
                    LastAccessed = session.LastAccessedAt,
                    IsAuthenticated = session.IsAuthenticated
                };

                return Success(userInfo, "User information retrieved successfully");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "GetUserInfo");
            }
        }

        /// <summary>
        /// Store data in the current user's session
        /// </summary>
        [HttpPost("session-data/{key}")]
        public async Task<IActionResult> SetSessionData(string key, [FromBody] object value)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(key))
                {
                    return BadRequest(new { error = "Key cannot be empty" });
                }

                var success = await SetSessionDataAsync(key, value);
                if (!success)
                {
                    return StatusCode(500, new { error = "Failed to store session data" });
                }

                return Success(new { key, value }, "Session data stored successfully");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "SetSessionData");
            }
        }

        /// <summary>
        /// Retrieve data from the current user's session
        /// </summary>
        [HttpGet("session-data/{key}")]
        public async Task<IActionResult> GetSessionData(string key)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(key))
                {
                    return BadRequest(new { error = "Key cannot be empty" });
                }

                var value = await GetSessionDataAsync<object>(key);
                if (value == null)
                {
                    return NotFound("Session data", key);
                }

                return Success(new { key, value }, "Session data retrieved successfully");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "GetSessionData");
            }
        }

        /// <summary>
        /// Get all session data for the current user
        /// </summary>
        [HttpGet("session-data")]
        public async Task<IActionResult> GetAllSessionData()
        {
            try
            {
                var session = await GetCurrentSessionAsync();
                if (session == null)
                {
                    return Unauthorized(new { error = "Unable to retrieve session" });
                }

                return Success(session.Data, "All session data retrieved successfully");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "GetAllSessionData");
            }
        }

        /// <summary>
        /// Store multiple key-value pairs in session
        /// </summary>
        [HttpPost("session-data")]
        public async Task<IActionResult> SetMultipleSessionData([FromBody] Dictionary<string, object> data)
        {
            try
            {
                if (data == null || !data.Any())
                {
                    return BadRequest(new { error = "Data cannot be empty" });
                }

                var session = await GetCurrentSessionAsync();
                if (session == null)
                {
                    return Unauthorized(new { error = "Unable to retrieve session" });
                }

                await _sessionManager.UpdateSessionAsync(session.SessionId, data);

                return Success(data, "Multiple session data items stored successfully");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "SetMultipleSessionData");
            }
        }

        /// <summary>
        /// Clear current user's session
        /// </summary>
        [HttpDelete("session")]
        public async Task<IActionResult> ClearSession()
        {
            try
            {
                var success = await InvalidateCurrentSessionAsync();
                if (!success)
                {
                    return StatusCode(500, new { error = "Failed to clear session" });
                }

                return Success(message: "Session cleared successfully");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "ClearSession");
            }
        }

        /// <summary>
        /// Refresh current user's session (extend expiration)
        /// </summary>
        [HttpPost("session/refresh")]
        public async Task<IActionResult> RefreshSession()
        {
            try
            {
                var session = await GetCurrentSessionAsync();
                if (session == null)
                {
                    return Unauthorized(new { error = "Unable to retrieve session" });
                }

                await _sessionManager.RefreshSessionAsync(session.SessionId);

                return Success(new { sessionId = session.SessionId }, "Session refreshed successfully");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "RefreshSession");
            }
        }

        /// <summary>
        /// Demonstrate session-based counter functionality
        /// </summary>
        [HttpPost("counter/increment")]
        public async Task<IActionResult> IncrementCounter()
        {
            try
            {
                var currentCount = await GetSessionDataAsync<int>("counter");
                var newCount = currentCount + 1;

                await SetSessionDataAsync("counter", newCount);

                return Success(new { counter = newCount }, "Counter incremented successfully");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "IncrementCounter");
            }
        }

        /// <summary>
        /// Get current counter value
        /// </summary>
        [HttpGet("counter")]
        public async Task<IActionResult> GetCounter()
        {
            try
            {
                var counter = await GetSessionDataAsync<int>("counter");
                return Success(new { counter }, "Counter value retrieved successfully");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "GetCounter");
            }
        }

        /// <summary>
        /// Reset counter to zero
        /// </summary>
        [HttpDelete("counter")]
        public async Task<IActionResult> ResetCounter()
        {
            try
            {
                await SetSessionDataAsync("counter", 0);
                return Success(new { counter = 0 }, "Counter reset successfully");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "ResetCounter");
            }
        }

        /// <summary>
        /// Health check endpoint that doesn't require authentication
        /// </summary>
        [HttpGet("health")]
        [AllowAnonymous]
        public IActionResult HealthCheck()
        {
            return Ok(new
            {
                status = "healthy",
                timestamp = DateTime.UtcNow,
                version = "1.0.0"
            });
        }
    }
}
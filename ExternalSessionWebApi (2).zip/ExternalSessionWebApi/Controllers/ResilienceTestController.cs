using ExternalSessionWebApi.Interfaces;
using ExternalSessionWebApi.Stores;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ExternalSessionWebApi.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    public class ResilienceTestController : BaseApiController
    {
        private readonly IServiceProvider _serviceProvider;

        public ResilienceTestController(
            ISessionManager sessionManager,
            IWindowsAuthenticationService authService,
            ILogger<ResilienceTestController> logger,
            IServiceProvider serviceProvider)
            : base(sessionManager, authService, logger)
        {
            _serviceProvider = serviceProvider;
        }

        /// <summary>
        /// Test session operations to verify resilience patterns
        /// </summary>
        [HttpPost("test-session-resilience")]
        public async Task<IActionResult> TestSessionResilience()
        {
            try
            {
                var sessionContext = await GetCurrentSessionAsync();
                if (sessionContext == null)
                {
                    return BadRequest("No active session found");
                }

                // Test setting session data
                await _sessionManager.SetSessionDataAsync(sessionContext.SessionId, "test_key", "test_value");
                
                // Test getting session data
                var retrievedValue = await _sessionManager.GetSessionDataAsync<string>(sessionContext.SessionId, "test_key");
                
                // Test updating session
                await _sessionManager.UpdateSessionAsync(sessionContext.SessionId, new Dictionary<string, object>
                {
                    ["resilience_test"] = DateTime.UtcNow,
                    ["test_counter"] = 1
                });

                var sessionStore = _serviceProvider.GetRequiredService<ISessionStore>();
                var isResilient = sessionStore is ResilientSessionStore;
                var usingFallback = sessionStore is ResilientSessionStore resilientStore && resilientStore.IsUsingFallback;

                var result = new
                {
                    SessionId = sessionContext.SessionId,
                    TestValue = retrievedValue,
                    IsResilientStore = isResilient,
                    UsingFallback = usingFallback,
                    StoreType = sessionStore.GetType().Name,
                    TestCompleted = true,
                    Timestamp = DateTime.UtcNow
                };

                return Success(result, "Session resilience test completed successfully");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "TestSessionResilience");
            }
        }

        /// <summary>
        /// Get current resilience status
        /// </summary>
        [HttpGet("resilience-status")]
        public IActionResult GetResilienceStatus()
        {
            try
            {
                var sessionStore = _serviceProvider.GetRequiredService<ISessionStore>();
                
                var status = new
                {
                    IsResilientStore = sessionStore is ResilientSessionStore,
                    UsingFallback = sessionStore is ResilientSessionStore resilientStore && resilientStore.IsUsingFallback,
                    StoreType = sessionStore.GetType().Name,
                    Timestamp = DateTime.UtcNow
                };

                return Success(status, "Resilience status retrieved");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "GetResilienceStatus");
            }
        }
    }
}
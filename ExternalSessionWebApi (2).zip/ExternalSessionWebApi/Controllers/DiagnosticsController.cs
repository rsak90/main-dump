using ExternalSessionWebApi.Interfaces;
using ExternalSessionWebApi.Stores;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

namespace ExternalSessionWebApi.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    public class DiagnosticsController : BaseApiController
    {
        private readonly IServiceProvider _serviceProvider;

        public DiagnosticsController(
            ISessionManager sessionManager,
            IWindowsAuthenticationService authService,
            ILogger<DiagnosticsController> logger,
            IServiceProvider serviceProvider)
            : base(sessionManager, authService, logger)
        {
            _serviceProvider = serviceProvider;
        }

        /// <summary>
        /// Get application health status
        /// </summary>
        [HttpGet("health")]
        public async Task<IActionResult> GetHealth()
        {
            try
            {
                var healthStatus = new
                {
                    Status = "Healthy",
                    Timestamp = DateTime.UtcNow,
                    Version = Assembly.GetExecutingAssembly().GetName().Version?.ToString(),
                    Environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"),
                    MachineName = Environment.MachineName,
                    ProcessId = Environment.ProcessId,
                    WorkingSet = GC.GetTotalMemory(false),
                    SessionStore = await CheckSessionStoreHealthAsync()
                };

                return Success(healthStatus, "Health check completed");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "HealthCheck");
            }
        }

        /// <summary>
        /// Get session statistics
        /// </summary>
        [HttpGet("session-stats")]
        public async Task<IActionResult> GetSessionStats()
        {
            try
            {
                var sessionStore = _serviceProvider.GetRequiredService<ISessionStore>();
                var expiredSessions = await sessionStore.GetExpiredSessionsAsync();

                var stats = new
                {
                    ExpiredSessionsCount = expiredSessions.Count(),
                    Timestamp = DateTime.UtcNow,
                    CurrentUser = GetCurrentUserId(),
                    CurrentSession = (await GetCurrentSessionAsync())?.SessionId
                };

                return Success(stats, "Session statistics retrieved");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "GetSessionStats");
            }
        }

        /// <summary>
        /// Cleanup expired sessions manually
        /// </summary>
        [HttpPost("cleanup-sessions")]
        public async Task<IActionResult> CleanupExpiredSessions()
        {
            try
            {
                var sessionStore = _serviceProvider.GetRequiredService<ISessionStore>();
                var expiredSessions = await sessionStore.GetExpiredSessionsAsync();
                var expiredCount = expiredSessions.Count();

                await sessionStore.CleanupExpiredSessionsAsync();

                return Success(new { CleanedUpCount = expiredCount }, "Expired sessions cleaned up");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "CleanupExpiredSessions");
            }
        }

        /// <summary>
        /// Get system information
        /// </summary>
        [HttpGet("system-info")]
        public IActionResult GetSystemInfo()
        {
            try
            {
                var systemInfo = new
                {
                    OperatingSystem = Environment.OSVersion.ToString(),
                    ProcessorCount = Environment.ProcessorCount,
                    MachineName = Environment.MachineName,
                    UserName = Environment.UserName,
                    WorkingDirectory = Environment.CurrentDirectory,
                    RuntimeVersion = Environment.Version.ToString(),
                    Is64BitProcess = Environment.Is64BitProcess,
                    Is64BitOperatingSystem = Environment.Is64BitOperatingSystem,
                    SystemPageSize = Environment.SystemPageSize,
                    TickCount = Environment.TickCount64,
                    Timestamp = DateTime.UtcNow
                };

                return Success(systemInfo, "System information retrieved");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "GetSystemInfo");
            }
        }

        /// <summary>
        /// Get application configuration (non-sensitive data only)
        /// </summary>
        [HttpGet("config")]
        public IActionResult GetConfiguration()
        {
            try
            {
                var configuration = _serviceProvider.GetRequiredService<IConfiguration>();
                
                var configInfo = new
                {
                    SessionProvider = configuration["SessionConfiguration:Provider"],
                    DefaultExpiration = configuration["SessionConfiguration:DefaultExpiration"],
                    CleanupInterval = configuration["SessionConfiguration:CleanupIntervalMinutes"],
                    EnableHealthChecks = configuration["SessionConfiguration:EnableHealthChecks"],
                    ResilienceEnabled = configuration["SessionConfiguration:Resilience:EnableFallback"],
                    CircuitBreakerEnabled = configuration["SessionConfiguration:Resilience:CircuitBreaker:Enabled"],
                    RetryEnabled = configuration["SessionConfiguration:Resilience:Retry:Enabled"],
                    Environment = configuration["ASPNETCORE_ENVIRONMENT"],
                    Timestamp = DateTime.UtcNow
                };

                return Success(configInfo, "Configuration information retrieved");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "GetConfiguration");
            }
        }

        /// <summary>
        /// Get resilience status and circuit breaker state
        /// </summary>
        [HttpGet("resilience-status")]
        public async Task<IActionResult> GetResilienceStatus()
        {
            try
            {
                var sessionStore = _serviceProvider.GetRequiredService<ISessionStore>();
                
                var resilienceStatus = new
                {
                    IsResilientStore = sessionStore is ResilientSessionStore,
                    UsingFallback = sessionStore is ResilientSessionStore resilientStore && resilientStore.IsUsingFallback,
                    StoreType = sessionStore.GetType().Name,
                    Timestamp = DateTime.UtcNow,
                    HealthCheck = await CheckSessionStoreHealthAsync()
                };

                return Success(resilienceStatus, "Resilience status retrieved");
            }
            catch (Exception ex)
            {
                return HandleError(ex, "GetResilienceStatus");
            }
        }

        private async Task<object> CheckSessionStoreHealthAsync()
        {
            try
            {
                var sessionStore = _serviceProvider.GetRequiredService<ISessionStore>();
                
                // Try to perform a basic operation to check if the store is accessible
                var testSessionId = Guid.NewGuid().ToString();
                var exists = await sessionStore.ExistsAsync(testSessionId);
                
                return new
                {
                    Status = "Healthy",
                    Accessible = true,
                    TestPerformed = true
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Session store health check failed");
                return new
                {
                    Status = "Unhealthy",
                    Accessible = false,
                    Error = ex.Message,
                    TestPerformed = true
                };
            }
        }
    }
}
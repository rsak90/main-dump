using ExternalSessionWebApi.Interfaces;
using ExternalSessionWebApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Principal;

namespace ExternalSessionWebApi.Controllers
{
    [ApiController]
    [Authorize]
    public abstract class BaseApiController : ControllerBase
    {
        protected readonly ISessionManager _sessionManager;
        protected readonly IWindowsAuthenticationService _authService;
        protected readonly ILogger _logger;

        protected BaseApiController(
            ISessionManager sessionManager,
            IWindowsAuthenticationService authService,
            ILogger logger)
        {
            _sessionManager = sessionManager;
            _authService = authService;
            _logger = logger;
        }

        protected async Task<SessionContext?> GetCurrentSessionAsync()
        {
            try
            {
                var userId = GetCurrentUserId();
                if (string.IsNullOrEmpty(userId))
                {
                    _logger.LogWarning("Unable to get current user ID");
                    return null;
                }

                return await _sessionManager.GetOrCreateSessionAsync(userId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting current session");
                return null;
            }
        }

        protected string GetCurrentUserId()
        {
            try
            {
                if (User?.Identity is WindowsIdentity windowsIdentity)
                {
                    return _authService.ExtractUserIdentity(windowsIdentity);
                }

                // Fallback to generic identity
                return User?.Identity?.Name ?? string.Empty;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting user identity");
                return string.Empty;
            }
        }

        protected string GetCurrentUserDomain()
        {
            try
            {
                if (User?.Identity is WindowsIdentity windowsIdentity)
                {
                    return _authService.ExtractDomainName(windowsIdentity);
                }

                return Environment.MachineName;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting user domain");
                return Environment.MachineName;
            }
        }

        protected async Task<T?> GetSessionDataAsync<T>(string key)
        {
            try
            {
                var session = await GetCurrentSessionAsync();
                if (session == null)
                {
                    return default(T);
                }

                return await _sessionManager.GetSessionDataAsync<T>(session.SessionId, key);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting session data for key {Key}", key);
                return default(T);
            }
        }

        protected async Task<bool> SetSessionDataAsync(string key, object value)
        {
            try
            {
                var session = await GetCurrentSessionAsync();
                if (session == null)
                {
                    return false;
                }

                await _sessionManager.SetSessionDataAsync(session.SessionId, key, value);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error setting session data for key {Key}", key);
                return false;
            }
        }

        protected async Task<bool> InvalidateCurrentSessionAsync()
        {
            try
            {
                var session = await GetCurrentSessionAsync();
                if (session == null)
                {
                    return false;
                }

                await _sessionManager.InvalidateSessionAsync(session.SessionId);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error invalidating current session");
                return false;
            }
        }

        protected IActionResult HandleError(Exception ex, string operation)
        {
            _logger.LogError(ex, "Error during {Operation}", operation);
            
            return ex switch
            {
                UnauthorizedAccessException => Unauthorized(new { error = "Access denied", operation }),
                ArgumentException => BadRequest(new { error = ex.Message, operation }),
                _ => StatusCode(500, new { error = "Internal server error", operation, timestamp = DateTime.UtcNow })
            };
        }

        protected IActionResult Success(object? data = null, string? message = null)
        {
            var response = new
            {
                success = true,
                message = message ?? "Operation completed successfully",
                data,
                timestamp = DateTime.UtcNow
            };

            return Ok(response);
        }

        protected IActionResult NotFound(string resource, string identifier)
        {
            return NotFound(new
            {
                error = $"{resource} not found",
                identifier,
                timestamp = DateTime.UtcNow
            });
        }
    }
}
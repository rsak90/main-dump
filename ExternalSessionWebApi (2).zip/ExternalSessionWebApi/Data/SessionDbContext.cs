using ExternalSessionWebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace ExternalSessionWebApi.Data
{
    public class SessionDbContext : DbContext
    {
        public SessionDbContext(DbContextOptions<SessionDbContext> options) : base(options)
        {
        }

        public DbSet<SessionEntity> Sessions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<SessionEntity>(entity =>
            {
                entity.HasKey(e => e.SessionId);
                
                entity.HasIndex(e => e.UserId)
                    .HasDatabaseName("IX_Sessions_UserId");
                
                entity.HasIndex(e => e.ExpiresAt)
                    .HasDatabaseName("IX_Sessions_ExpiresAt");
                
                entity.HasIndex(e => e.LastAccessedAt)
                    .HasDatabaseName("IX_Sessions_LastAccessedAt");

                entity.Property(e => e.SessionId)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(255);

                if (Database.IsSqlServer())
                {
                    entity.Property(e => e.DataJson)
                        .HasColumnType("nvarchar(max)")
                        .HasDefaultValue("{}");
                }
                else
                {
                    entity.Property(e => e.DataJson)
                        .HasDefaultValue("{}");
                }

                // Use different default value SQL based on provider
                if (Database.IsSqlServer())
                {
                    entity.Property(e => e.CreatedAt)
                        .HasDefaultValueSql("GETUTCDATE()");

                    entity.Property(e => e.LastAccessedAt)
                        .HasDefaultValueSql("GETUTCDATE()");
                }
                else if (Database.IsSqlite())
                {
                    entity.Property(e => e.CreatedAt)
                        .HasDefaultValueSql("datetime('now')");

                    entity.Property(e => e.LastAccessedAt)
                        .HasDefaultValueSql("datetime('now')");
                }
                else if (Database.IsNpgsql())
                {
                    entity.Property(e => e.CreatedAt)
                        .HasDefaultValueSql("NOW()");

                    entity.Property(e => e.LastAccessedAt)
                        .HasDefaultValueSql("NOW()");
                }
            });
        }
    }
}
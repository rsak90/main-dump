using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace ExternalSessionWebApi.Data
{
    public class SessionDbContextFactory : IDesignTimeDbContextFactory<SessionDbContext>
    {
        public SessionDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<SessionDbContext>();
            
            // Use SQLite for design-time migrations
            optionsBuilder.UseSqlite("Data Source=sessions.db");

            return new SessionDbContext(optionsBuilder.Options);
        }
    }
}
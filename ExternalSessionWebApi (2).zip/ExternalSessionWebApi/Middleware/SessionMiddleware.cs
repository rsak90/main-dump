using ExternalSessionWebApi.Interfaces;
using System.Security.Principal;

namespace ExternalSessionWebApi.Middleware
{
    public class SessionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<SessionMiddleware> _logger;

        public SessionMiddleware(RequestDelegate next, ILogger<SessionMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context, ISessionManager sessionManager, IWindowsAuthenticationService authService)
        {
            var startTime = DateTime.UtcNow;
            var requestId = Guid.NewGuid().ToString("N")[..8];

            try
            {
                // Log incoming request
                _logger.LogInformation("Request {RequestId}: {Method} {Path} from {User}",
                    requestId, context.Request.Method, context.Request.Path, 
                    context.User?.Identity?.Name ?? "Anonymous");

                // Skip session management for health checks and anonymous endpoints
                if (ShouldSkipSessionManagement(context))
                {
                    await _next(context);
                    return;
                }

                // Ensure user is authenticated
                if (!context.User?.Identity?.IsAuthenticated == true)
                {
                    _logger.LogWarning("Request {RequestId}: Unauthenticated user attempting to access protected resource", requestId);
                    await _next(context);
                    return;
                }

                // Get or create session for authenticated user
                var userId = ExtractUserId(context, authService);
                if (!string.IsNullOrEmpty(userId))
                {
                    var session = await sessionManager.GetOrCreateSessionAsync(userId);
                    if (session != null)
                    {
                        // Add session information to request context
                        context.Items["SessionId"] = session.SessionId;
                        context.Items["SessionContext"] = session;

                        _logger.LogDebug("Request {RequestId}: Session {SessionId} associated with user {UserId}",
                            requestId, session.SessionId, userId);
                    }
                }

                // Continue with the request
                await _next(context);

                // Log successful completion
                var duration = DateTime.UtcNow - startTime;
                _logger.LogInformation("Request {RequestId}: Completed in {Duration}ms with status {StatusCode}",
                    requestId, duration.TotalMilliseconds, context.Response.StatusCode);
            }
            catch (Exception ex)
            {
                var duration = DateTime.UtcNow - startTime;
                _logger.LogError(ex, "Request {RequestId}: Failed after {Duration}ms", requestId, duration.TotalMilliseconds);

                // Set error response if not already set
                if (!context.Response.HasStarted)
                {
                    context.Response.StatusCode = 500;
                    context.Response.ContentType = "application/json";
                    
                    var errorResponse = new
                    {
                        error = "Internal server error",
                        requestId,
                        timestamp = DateTime.UtcNow
                    };

                    await context.Response.WriteAsync(System.Text.Json.JsonSerializer.Serialize(errorResponse));
                }
            }
        }

        private bool ShouldSkipSessionManagement(HttpContext context)
        {
            var path = context.Request.Path.Value?.ToLowerInvariant() ?? string.Empty;
            
            // Skip for health checks, swagger, and other non-business endpoints
            return path.Contains("/health") ||
                   path.Contains("/swagger") ||
                   path.Contains("/openapi") ||
                   path.Contains("/_framework") ||
                   path.Contains("/favicon.ico");
        }

        private string ExtractUserId(HttpContext context, IWindowsAuthenticationService authService)
        {
            try
            {
                if (context.User?.Identity is WindowsIdentity windowsIdentity)
                {
                    return authService.ExtractUserIdentity(windowsIdentity);
                }

                // Fallback to generic identity
                return context.User?.Identity?.Name ?? string.Empty;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting user ID from context");
                return string.Empty;
            }
        }
    }

    public static class SessionMiddlewareExtensions
    {
        public static IApplicationBuilder UseSessionManagement(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<SessionMiddleware>();
        }
    }
}
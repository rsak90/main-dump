using ExternalSessionWebApi.Interfaces;
using ExternalSessionWebApi.Models;
using Microsoft.Extensions.Options;
using System.Collections.Concurrent;

namespace ExternalSessionWebApi.Services
{
    public class ResilientSessionManager : ISessionManager
    {
        private readonly ISessionManager _primarySessionManager;
        private readonly ILogger<ResilientSessionManager> _logger;
        private readonly SessionConfiguration _config;
        
        // In-memory fallback store
        private readonly ConcurrentDictionary<string, SessionData> _fallbackStore = new();
        private readonly ConcurrentDictionary<string, string> _userSessionMap = new();
        
        // Circuit breaker state
        private int _failureCount = 0;
        private DateTime _lastFailureTime = DateTime.MinValue;
        private bool _circuitOpen = false;
        private readonly object _circuitLock = new object();
        
        // Configuration
        private const int MaxFailures = 5;
        private static readonly TimeSpan CircuitOpenDuration = TimeSpan.FromMinutes(2);
        private static readonly TimeSpan FallbackCleanupInterval = TimeSpan.FromMinutes(30);
        
        public ResilientSessionManager(
            SessionManager primarySessionManager,
            IOptions<SessionConfiguration> config,
            ILogger<ResilientSessionManager> logger)
        {
            _primarySessionManager = primarySessionManager;
            _config = config.Value;
            _logger = logger;
            
            // Start background cleanup for fallback store
            _ = Task.Run(FallbackCleanupLoop);
        }

        public async Task<SessionContext> GetOrCreateSessionAsync(string userId)
        {
            if (IsCircuitOpen())
            {
                _logger.LogWarning("Circuit breaker is open, using fallback session store for user {UserId}", userId);
                return await GetOrCreateFallbackSessionAsync(userId);
            }

            try
            {
                var result = await _primarySessionManager.GetOrCreateSessionAsync(userId);
                RecordSuccess();
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Primary session manager failed for user {UserId}, falling back to in-memory store", userId);
                RecordFailure();
                return await GetOrCreateFallbackSessionAsync(userId);
            }
        }

        public async Task UpdateSessionAsync(string sessionId, object data)
        {
            if (IsCircuitOpen())
            {
                UpdateFallbackSession(sessionId, data);
                return;
            }

            try
            {
                await _primarySessionManager.UpdateSessionAsync(sessionId, data);
                RecordSuccess();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Primary session manager failed to update session {SessionId}, updating fallback store", sessionId);
                RecordFailure();
                UpdateFallbackSession(sessionId, data);
            }
        }

        public async Task<T?> GetSessionDataAsync<T>(string sessionId, string key)
        {
            if (IsCircuitOpen())
            {
                return GetFallbackSessionData<T>(sessionId, key);
            }

            try
            {
                var result = await _primarySessionManager.GetSessionDataAsync<T>(sessionId, key);
                RecordSuccess();
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Primary session manager failed to get session data for {SessionId}, checking fallback store", sessionId);
                RecordFailure();
                return GetFallbackSessionData<T>(sessionId, key);
            }
        }

        public async Task SetSessionDataAsync(string sessionId, string key, object value)
        {
            if (IsCircuitOpen())
            {
                SetFallbackSessionData(sessionId, key, value);
                return;
            }

            try
            {
                await _primarySessionManager.SetSessionDataAsync(sessionId, key, value);
                RecordSuccess();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Primary session manager failed to set session data for {SessionId}, using fallback store", sessionId);
                RecordFailure();
                SetFallbackSessionData(sessionId, key, value);
            }
        }

        public async Task InvalidateSessionAsync(string sessionId)
        {
            // Always try to invalidate from both stores
            var primaryTask = InvalidatePrimarySessionAsync(sessionId);
            InvalidateFallbackSession(sessionId);
            
            try
            {
                await primaryTask;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to invalidate session {SessionId} from primary store", sessionId);
            }
        }

        public async Task<bool> IsSessionValidAsync(string sessionId)
        {
            if (IsCircuitOpen())
            {
                return IsFallbackSessionValid(sessionId);
            }

            try
            {
                var result = await _primarySessionManager.IsSessionValidAsync(sessionId);
                RecordSuccess();
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Primary session manager failed to check session validity for {SessionId}, checking fallback store", sessionId);
                RecordFailure();
                return IsFallbackSessionValid(sessionId);
            }
        }

        public async Task RefreshSessionAsync(string sessionId)
        {
            if (IsCircuitOpen())
            {
                RefreshFallbackSession(sessionId);
                return;
            }

            try
            {
                await _primarySessionManager.RefreshSessionAsync(sessionId);
                RecordSuccess();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Primary session manager failed to refresh session {SessionId}, refreshing fallback store", sessionId);
                RecordFailure();
                RefreshFallbackSession(sessionId);
            }
        }

        private bool IsCircuitOpen()
        {
            lock (_circuitLock)
            {
                if (_circuitOpen && DateTime.UtcNow - _lastFailureTime > CircuitOpenDuration)
                {
                    _logger.LogInformation("Circuit breaker transitioning to half-open state");
                    _circuitOpen = false;
                    _failureCount = 0;
                }
                
                return _circuitOpen;
            }
        }

        private void RecordSuccess()
        {
            lock (_circuitLock)
            {
                _failureCount = 0;
                if (_circuitOpen)
                {
                    _logger.LogInformation("Circuit breaker closing - primary session store is healthy");
                    _circuitOpen = false;
                }
            }
        }

        private void RecordFailure()
        {
            lock (_circuitLock)
            {
                _failureCount++;
                _lastFailureTime = DateTime.UtcNow;
                
                if (_failureCount >= MaxFailures && !_circuitOpen)
                {
                    _logger.LogWarning("Circuit breaker opening - primary session store has failed {FailureCount} times", _failureCount);
                    _circuitOpen = true;
                }
            }
        }

        private async Task<SessionContext> GetOrCreateFallbackSessionAsync(string userId)
        {
            if (_userSessionMap.TryGetValue(userId, out var existingSessionId) &&
                _fallbackStore.TryGetValue(existingSessionId, out var existingSession) &&
                !existingSession.IsExpired)
            {
                existingSession.LastAccessedAt = DateTime.UtcNow;
                return MapToSessionContext(existingSession);
            }

            // Create new fallback session
            var sessionId = Guid.NewGuid().ToString("N");
            var sessionData = new SessionData
            {
                SessionId = sessionId,
                UserId = userId,
                CreatedAt = DateTime.UtcNow,
                LastAccessedAt = DateTime.UtcNow,
                ExpiresAt = DateTime.UtcNow.Add(_config.DefaultExpiration),
                Data = new Dictionary<string, object>()
            };

            _fallbackStore[sessionId] = sessionData;
            _userSessionMap[userId] = sessionId;

            _logger.LogInformation("Created fallback session {SessionId} for user {UserId}", sessionId, userId);
            return MapToSessionContext(sessionData);
        }

        private void UpdateFallbackSession(string sessionId, object data)
        {
            if (_fallbackStore.TryGetValue(sessionId, out var session))
            {
                if (data is Dictionary<string, object> dataDict)
                {
                    foreach (var kvp in dataDict)
                    {
                        session.Data[kvp.Key] = kvp.Value;
                    }
                }
                session.LastAccessedAt = DateTime.UtcNow;
            }
        }

        private T? GetFallbackSessionData<T>(string sessionId, string key)
        {
            if (_fallbackStore.TryGetValue(sessionId, out var session) && 
                !session.IsExpired &&
                session.Data.TryGetValue(key, out var value))
            {
                return (T?)value;
            }
            return default(T);
        }

        private void SetFallbackSessionData(string sessionId, string key, object value)
        {
            if (_fallbackStore.TryGetValue(sessionId, out var session) && !session.IsExpired)
            {
                session.Data[key] = value;
                session.LastAccessedAt = DateTime.UtcNow;
            }
        }

        private void InvalidateFallbackSession(string sessionId)
        {
            if (_fallbackStore.TryRemove(sessionId, out var session))
            {
                // Remove from user mapping
                var userEntry = _userSessionMap.FirstOrDefault(kvp => kvp.Value == sessionId);
                if (!userEntry.Equals(default(KeyValuePair<string, string>)))
                {
                    _userSessionMap.TryRemove(userEntry.Key, out _);
                }
            }
        }

        private bool IsFallbackSessionValid(string sessionId)
        {
            return _fallbackStore.TryGetValue(sessionId, out var session) && !session.IsExpired;
        }

        private void RefreshFallbackSession(string sessionId)
        {
            if (_fallbackStore.TryGetValue(sessionId, out var session))
            {
                session.LastAccessedAt = DateTime.UtcNow;
                session.ExpiresAt = DateTime.UtcNow.Add(_config.DefaultExpiration);
            }
        }

        private async Task InvalidatePrimarySessionAsync(string sessionId)
        {
            if (!IsCircuitOpen())
            {
                await _primarySessionManager.InvalidateSessionAsync(sessionId);
            }
        }

        private SessionContext MapToSessionContext(SessionData sessionData)
        {
            return new SessionContext
            {
                SessionId = sessionData.SessionId,
                UserId = sessionData.UserId,
                UserName = sessionData.UserId,
                CreatedAt = sessionData.CreatedAt,
                LastAccessedAt = sessionData.LastAccessedAt,
                IsAuthenticated = true,
                Data = sessionData.Data
            };
        }

        private async Task FallbackCleanupLoop()
        {
            while (true)
            {
                try
                {
                    await Task.Delay(FallbackCleanupInterval);
                    
                    var expiredSessions = _fallbackStore
                        .Where(kvp => kvp.Value.IsExpired)
                        .Select(kvp => kvp.Key)
                        .ToList();

                    foreach (var sessionId in expiredSessions)
                    {
                        InvalidateFallbackSession(sessionId);
                    }

                    if (expiredSessions.Any())
                    {
                        _logger.LogInformation("Cleaned up {Count} expired fallback sessions", expiredSessions.Count);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error during fallback session cleanup");
                }
            }
        }
    }
}
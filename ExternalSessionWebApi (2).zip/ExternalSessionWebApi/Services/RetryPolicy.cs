using System.Net.Sockets;

namespace ExternalSessionWebApi.Services
{
    public class RetryPolicy
    {
        private readonly int _maxRetries;
        private readonly TimeSpan _baseDelay;
        private readonly double _backoffMultiplier;
        private readonly ILogger<RetryPolicy> _logger;

        public RetryPolicy(int maxRetries, TimeSpan baseDelay, double backoffMultiplier, ILogger<RetryPolicy> logger)
        {
            _maxRetries = maxRetries;
            _baseDelay = baseDelay;
            _backoffMultiplier = backoffMultiplier;
            _logger = logger;
        }

        public async Task<T> ExecuteAsync<T>(Func<Task<T>> operation, Func<Exception, bool>? shouldRetry = null)
        {
            var attempt = 0;
            Exception? lastException = null;

            while (attempt <= _maxRetries)
            {
                try
                {
                    return await operation();
                }
                catch (Exception ex)
                {
                    lastException = ex;
                    
                    if (attempt == _maxRetries || (shouldRetry != null && !shouldRetry(ex)))
                    {
                        _logger.LogError(ex, "Operation failed after {Attempts} attempts", attempt + 1);
                        throw;
                    }

                    var delay = CalculateDelay(attempt);
                    _logger.LogWarning(ex, "Operation failed on attempt {Attempt}, retrying in {Delay}ms", 
                        attempt + 1, delay.TotalMilliseconds);
                    
                    await Task.Delay(delay);
                    attempt++;
                }
            }

            throw lastException ?? new InvalidOperationException("Retry policy failed without exception");
        }

        public async Task ExecuteAsync(Func<Task> operation, Func<Exception, bool>? shouldRetry = null)
        {
            var attempt = 0;
            Exception? lastException = null;

            while (attempt <= _maxRetries)
            {
                try
                {
                    await operation();
                    return;
                }
                catch (Exception ex)
                {
                    lastException = ex;
                    
                    if (attempt == _maxRetries || (shouldRetry != null && !shouldRetry(ex)))
                    {
                        _logger.LogError(ex, "Operation failed after {Attempts} attempts", attempt + 1);
                        throw;
                    }

                    var delay = CalculateDelay(attempt);
                    _logger.LogWarning(ex, "Operation failed on attempt {Attempt}, retrying in {Delay}ms", 
                        attempt + 1, delay.TotalMilliseconds);
                    
                    await Task.Delay(delay);
                    attempt++;
                }
            }

            throw lastException ?? new InvalidOperationException("Retry policy failed without exception");
        }

        private TimeSpan CalculateDelay(int attempt)
        {
            var delay = TimeSpan.FromMilliseconds(_baseDelay.TotalMilliseconds * Math.Pow(_backoffMultiplier, attempt));
            
            // Cap the delay at 30 seconds
            var maxDelay = TimeSpan.FromSeconds(30);
            return delay > maxDelay ? maxDelay : delay;
        }

        public static bool IsTransientException(Exception ex)
        {
            return ex switch
            {
                TimeoutException => true,
                TaskCanceledException => true,
                HttpRequestException => true,
                SocketException => true,
                _ when ex.Message.Contains("timeout", StringComparison.OrdinalIgnoreCase) => true,
                _ when ex.Message.Contains("connection", StringComparison.OrdinalIgnoreCase) => true,
                _ when ex.Message.Contains("network", StringComparison.OrdinalIgnoreCase) => true,
                _ => false
            };
        }
    }
}
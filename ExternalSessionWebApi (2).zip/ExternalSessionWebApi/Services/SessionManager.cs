using ExternalSessionWebApi.Interfaces;
using ExternalSessionWebApi.Models;
using Microsoft.Extensions.Options;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace ExternalSessionWebApi.Services
{
    public class SessionManager : ISessionManager
    {
        private readonly ISessionStore _sessionStore;
        private readonly SessionConfiguration _config;
        private readonly ILogger<SessionManager> _logger;

        public SessionManager(
            ISessionStore sessionStore,
            IOptions<SessionConfiguration> config,
            ILogger<SessionManager> logger)
        {
            _sessionStore = sessionStore;
            _config = config.Value;
            _logger = logger;
        }

        public async Task<SessionContext> GetOrCreateSessionAsync(string userId)
        {
            try
            {
                // Try to find existing session for user
                var existingSession = await FindExistingSessionForUserAsync(userId);
                if (existingSession != null && !existingSession.IsExpired)
                {
                    await _sessionStore.UpdateLastAccessedAsync(existingSession.SessionId);
                    return MapToSessionContext(existingSession);
                }

                // Create new session
                var sessionId = GenerateSessionId();
                var sessionData = new SessionData
                {
                    SessionId = sessionId,
                    UserId = userId,
                    CreatedAt = DateTime.UtcNow,
                    LastAccessedAt = DateTime.UtcNow,
                    ExpiresAt = DateTime.UtcNow.Add(_config.DefaultExpiration),
                    Data = new Dictionary<string, object>()
                };

                await _sessionStore.SetAsync(sessionId, sessionData, _config.DefaultExpiration);

                _logger.LogInformation("Created new session {SessionId} for user {UserId}", sessionId, userId);

                return MapToSessionContext(sessionData);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating or retrieving session for user {UserId}", userId);
                throw;
            }
        }

        public async Task UpdateSessionAsync(string sessionId, object data)
        {
            try
            {
                var session = await _sessionStore.GetAsync(sessionId);
                if (session == null || session.IsExpired)
                {
                    _logger.LogWarning("Attempted to update non-existent or expired session {SessionId}", sessionId);
                    return;
                }

                // Merge the new data
                if (data is Dictionary<string, object> dataDict)
                {
                    foreach (var kvp in dataDict)
                    {
                        session.Data[kvp.Key] = kvp.Value;
                    }
                }

                session.LastAccessedAt = DateTime.UtcNow;
                await _sessionStore.SetAsync(sessionId, session, _config.DefaultExpiration);

                _logger.LogDebug("Updated session {SessionId}", sessionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating session {SessionId}", sessionId);
                throw;
            }
        }

        public async Task<T?> GetSessionDataAsync<T>(string sessionId, string key)
        {
            try
            {
                var session = await _sessionStore.GetAsync(sessionId);
                if (session == null || session.IsExpired)
                {
                    return default(T);
                }

                if (session.Data.TryGetValue(key, out var value))
                {
                    if (value is JsonElement jsonElement)
                    {
                        return JsonSerializer.Deserialize<T>(jsonElement.GetRawText());
                    }
                    return (T)value;
                }

                return default(T);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving session data for key {Key} in session {SessionId}", key, sessionId);
                return default(T);
            }
        }

        public async Task SetSessionDataAsync(string sessionId, string key, object value)
        {
            try
            {
                var session = await _sessionStore.GetAsync(sessionId);
                if (session == null || session.IsExpired)
                {
                    _logger.LogWarning("Attempted to set data on non-existent or expired session {SessionId}", sessionId);
                    return;
                }

                session.Data[key] = value;
                session.LastAccessedAt = DateTime.UtcNow;
                await _sessionStore.SetAsync(sessionId, session, _config.DefaultExpiration);

                _logger.LogDebug("Set session data for key {Key} in session {SessionId}", key, sessionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error setting session data for key {Key} in session {SessionId}", key, sessionId);
                throw;
            }
        }

        public async Task InvalidateSessionAsync(string sessionId)
        {
            try
            {
                await _sessionStore.RemoveAsync(sessionId);
                _logger.LogInformation("Invalidated session {SessionId}", sessionId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error invalidating session {SessionId}", sessionId);
                throw;
            }
        }

        public async Task<bool> IsSessionValidAsync(string sessionId)
        {
            try
            {
                var session = await _sessionStore.GetAsync(sessionId);
                return session != null && !session.IsExpired;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking session validity for {SessionId}", sessionId);
                return false;
            }
        }

        public async Task RefreshSessionAsync(string sessionId)
        {
            try
            {
                var session = await _sessionStore.GetAsync(sessionId);
                if (session != null && !session.IsExpired)
                {
                    session.LastAccessedAt = DateTime.UtcNow;
                    session.ExpiresAt = DateTime.UtcNow.Add(_config.DefaultExpiration);
                    await _sessionStore.SetAsync(sessionId, session, _config.DefaultExpiration);

                    _logger.LogDebug("Refreshed session {SessionId}", sessionId);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error refreshing session {SessionId}", sessionId);
                throw;
            }
        }

        private string GenerateSessionId()
        {
            using var rng = RandomNumberGenerator.Create();
            var bytes = new byte[32];
            rng.GetBytes(bytes);
            return Convert.ToBase64String(bytes).Replace("+", "-").Replace("/", "_").Replace("=", "");
        }

        private async Task<SessionData?> FindExistingSessionForUserAsync(string userId)
        {
            // This is a simplified implementation
            // In a real scenario, you might need to maintain a user-to-session mapping
            // or search through sessions (which could be expensive)
            // For now, we'll create a new session each time
            return null;
        }

        private SessionContext MapToSessionContext(SessionData sessionData)
        {
            return new SessionContext
            {
                SessionId = sessionData.SessionId,
                UserId = sessionData.UserId,
                UserName = sessionData.UserId, // In a real app, you'd get the display name
                CreatedAt = sessionData.CreatedAt,
                LastAccessedAt = sessionData.LastAccessedAt,
                IsAuthenticated = true,
                Data = sessionData.Data
            };
        }
    }
}
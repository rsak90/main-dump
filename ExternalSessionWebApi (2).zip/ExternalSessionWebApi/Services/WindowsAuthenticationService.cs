using ExternalSessionWebApi.Interfaces;
using System.Security.Principal;

namespace ExternalSessionWebApi.Services
{
    public class WindowsAuthenticationService : IWindowsAuthenticationService
    {
        private readonly ILogger<WindowsAuthenticationService> _logger;

        public WindowsAuthenticationService(ILogger<WindowsAuthenticationService> logger)
        {
            _logger = logger;
        }

        public async Task<WindowsIdentity?> ValidateWindowsCredentialsAsync(string username)
        {
            try
            {
                // In a real implementation, this would validate against Active Directory
                // For now, we'll work with the current Windows identity from the HTTP context
                var currentIdentity = WindowsIdentity.GetCurrent();
                
                if (currentIdentity != null && currentIdentity.IsAuthenticated)
                {
                    _logger.LogInformation("Windows authentication successful for user: {Username}", 
                        currentIdentity.Name);
                    return currentIdentity;
                }

                _logger.LogWarning("Windows authentication failed for user: {Username}", username);
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during Windows authentication for user: {Username}", username);
                return null;
            }
        }

        public string ExtractUserIdentity(WindowsIdentity identity)
        {
            if (identity?.Name == null)
                return string.Empty;

            // Extract just the username part (remove domain if present)
            var parts = identity.Name.Split('\\');
            return parts.Length > 1 ? parts[1] : parts[0];
        }

        public string ExtractDomainName(WindowsIdentity identity)
        {
            if (identity?.Name == null)
                return string.Empty;

            // Extract domain part if present
            var parts = identity.Name.Split('\\');
            return parts.Length > 1 ? parts[0] : Environment.MachineName;
        }

        public bool IsUserAuthenticated(WindowsIdentity? identity)
        {
            return identity != null && identity.IsAuthenticated;
        }
    }
}
namespace ExternalSessionWebApi.Services
{
    public enum CircuitBreakerState
    {
        Closed,
        Open,
        HalfOpen
    }

    public class CircuitBreaker
    {
        private readonly int _failureThreshold;
        private readonly TimeSpan _timeout;
        private readonly ILogger<CircuitBreaker> _logger;
        
        private int _failureCount;
        private DateTime _lastFailureTime;
        private CircuitBreakerState _state;
        private readonly object _lock = new object();

        public CircuitBreaker(int failureThreshold, TimeSpan timeout, ILogger<CircuitBreaker> logger)
        {
            _failureThreshold = failureThreshold;
            _timeout = timeout;
            _logger = logger;
            _state = CircuitBreakerState.Closed;
        }

        public CircuitBreakerState State => _state;

        public async Task<T> ExecuteAsync<T>(Func<Task<T>> operation)
        {
            if (_state == CircuitBreakerState.Open)
            {
                if (DateTime.UtcNow - _lastFailureTime < _timeout)
                {
                    throw new CircuitBreakerOpenException("Circuit breaker is open");
                }
                
                // Try to transition to half-open
                lock (_lock)
                {
                    if (_state == CircuitBreakerState.Open && DateTime.UtcNow - _lastFailureTime >= _timeout)
                    {
                        _state = CircuitBreakerState.HalfOpen;
                        _logger.LogInformation("Circuit breaker transitioning to half-open state");
                    }
                }
            }

            try
            {
                var result = await operation();
                OnSuccess();
                return result;
            }
            catch (Exception ex)
            {
                OnFailure(ex);
                throw;
            }
        }

        public async Task ExecuteAsync(Func<Task> operation)
        {
            if (_state == CircuitBreakerState.Open)
            {
                if (DateTime.UtcNow - _lastFailureTime < _timeout)
                {
                    throw new CircuitBreakerOpenException("Circuit breaker is open");
                }
                
                // Try to transition to half-open
                lock (_lock)
                {
                    if (_state == CircuitBreakerState.Open && DateTime.UtcNow - _lastFailureTime >= _timeout)
                    {
                        _state = CircuitBreakerState.HalfOpen;
                        _logger.LogInformation("Circuit breaker transitioning to half-open state");
                    }
                }
            }

            try
            {
                await operation();
                OnSuccess();
            }
            catch (Exception ex)
            {
                OnFailure(ex);
                throw;
            }
        }

        private void OnSuccess()
        {
            lock (_lock)
            {
                _failureCount = 0;
                if (_state == CircuitBreakerState.HalfOpen)
                {
                    _state = CircuitBreakerState.Closed;
                    _logger.LogInformation("Circuit breaker closed after successful operation");
                }
            }
        }

        private void OnFailure(Exception ex)
        {
            lock (_lock)
            {
                _failureCount++;
                _lastFailureTime = DateTime.UtcNow;

                if (_failureCount >= _failureThreshold)
                {
                    _state = CircuitBreakerState.Open;
                    _logger.LogWarning(ex, "Circuit breaker opened after {FailureCount} failures", _failureCount);
                }
                else
                {
                    _logger.LogWarning(ex, "Circuit breaker failure {FailureCount}/{Threshold}", 
                        _failureCount, _failureThreshold);
                }
            }
        }
    }

    public class CircuitBreakerOpenException : Exception
    {
        public CircuitBreakerOpenException(string message) : base(message)
        {
        }

        public CircuitBreakerOpenException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
using ExternalSessionWebApi.Interfaces;
using ExternalSessionWebApi.Models;
using ExternalSessionWebApi.Stores;
using ExternalSessionWebApi.Services;
using Microsoft.Extensions.Options;
using StackExchange.Redis;

namespace ExternalSessionWebApi.Services
{
    public class SessionStoreFactory
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly SessionConfiguration _config;
        private readonly ILogger<SessionStoreFactory> _logger;

        public SessionStoreFactory(
            IServiceProvider serviceProvider,
            IOptions<SessionConfiguration> config,
            ILogger<SessionStoreFactory> logger)
        {
            _serviceProvider = serviceProvider;
            _config = config.Value;
            _logger = logger;
        }

        public ISessionStore CreateSessionStore()
        {
            var primaryStore = _config.Provider.ToLowerInvariant() switch
            {
                "redis" => CreateRedisStore(),
                "sqlserver" => CreateSqlStore(),
                "postgresql" => CreateSqlStore(),
                "sqlite" => CreateSqlStore(),
                _ => throw new NotSupportedException($"Session provider '{_config.Provider}' is not supported")
            };

            // If resilience is disabled, return the primary store directly
            if (!_config.Resilience.EnableFallback && 
                !_config.Resilience.CircuitBreaker.Enabled && 
                !_config.Resilience.Retry.Enabled)
            {
                return primaryStore;
            }

            return CreateResilientStore(primaryStore);
        }

        private ISessionStore CreateRedisStore()
        {
            try
            {
                var redis = _serviceProvider.GetRequiredService<IConnectionMultiplexer>();
                var logger = _serviceProvider.GetRequiredService<ILogger<RedisSessionStore>>();
                return new RedisSessionStore(redis, logger);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create Redis session store");
                throw;
            }
        }

        private ISessionStore CreateSqlStore()
        {
            try
            {
                return _serviceProvider.GetRequiredService<SqlSessionStore>();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create SQL session store");
                throw;
            }
        }

        private ISessionStore CreateResilientStore(ISessionStore primaryStore)
        {
            try
            {
                // Create fallback store (always in-memory)
                var fallbackStore = _config.Resilience.EnableFallback 
                    ? new InMemorySessionStore(_serviceProvider.GetRequiredService<ILogger<InMemorySessionStore>>())
                    : primaryStore; // Use primary as fallback if fallback is disabled

                // Create circuit breaker
                var circuitBreaker = _config.Resilience.CircuitBreaker.Enabled
                    ? new CircuitBreaker(
                        _config.Resilience.CircuitBreaker.FailureThreshold,
                        _config.Resilience.CircuitBreaker.Timeout,
                        _serviceProvider.GetRequiredService<ILogger<CircuitBreaker>>())
                    : new CircuitBreaker(int.MaxValue, TimeSpan.MaxValue, 
                        _serviceProvider.GetRequiredService<ILogger<CircuitBreaker>>()); // Disabled circuit breaker

                // Create retry policy
                var retryPolicy = _config.Resilience.Retry.Enabled
                    ? new RetryPolicy(
                        _config.Resilience.Retry.MaxRetries,
                        _config.Resilience.Retry.BaseDelay,
                        _config.Resilience.Retry.BackoffMultiplier,
                        _serviceProvider.GetRequiredService<ILogger<RetryPolicy>>())
                    : new RetryPolicy(0, TimeSpan.Zero, 1.0, 
                        _serviceProvider.GetRequiredService<ILogger<RetryPolicy>>()); // Disabled retry policy

                return new ResilientSessionStore(
                    primaryStore,
                    fallbackStore,
                    circuitBreaker,
                    retryPolicy,
                    _serviceProvider.GetRequiredService<ILogger<ResilientSessionStore>>());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create resilient session store, falling back to primary store");
                return primaryStore;
            }
        }
    }
}
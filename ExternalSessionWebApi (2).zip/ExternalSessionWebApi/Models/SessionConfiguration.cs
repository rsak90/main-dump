using System.ComponentModel.DataAnnotations;

namespace ExternalSessionWebApi.Models
{
    public class SessionConfiguration
    {
        [Required]
        public string Provider { get; set; } = "SQLite"; // "Redis", "KeyDB", "PostgreSQL", "SqlServer", "SQLite"

        [Required]
        public string ConnectionString { get; set; } = string.Empty;

        public TimeSpan DefaultExpiration { get; set; } = TimeSpan.FromHours(24);

        public bool EnableDistributedLocking { get; set; } = false;

        public Dictionary<string, string> ProviderOptions { get; set; } = new();

        public int CleanupIntervalMinutes { get; set; } = 60;

        public bool EnableHealthChecks { get; set; } = true;

        // Resilience Configuration
        public ResilienceConfiguration Resilience { get; set; } = new();
    }

    public class ResilienceConfiguration
    {
        public bool EnableFallback { get; set; } = true;
        
        public CircuitBreakerConfiguration CircuitBreaker { get; set; } = new();
        
        public RetryConfiguration Retry { get; set; } = new();
    }

    public class CircuitBreakerConfiguration
    {
        public bool Enabled { get; set; } = true;
        
        public int FailureThreshold { get; set; } = 5;
        
        public TimeSpan Timeout { get; set; } = TimeSpan.FromMinutes(1);
    }

    public class RetryConfiguration
    {
        public bool Enabled { get; set; } = true;
        
        public int MaxRetries { get; set; } = 3;
        
        public TimeSpan BaseDelay { get; set; } = TimeSpan.FromMilliseconds(100);
        
        public double BackoffMultiplier { get; set; } = 2.0;
    }
}
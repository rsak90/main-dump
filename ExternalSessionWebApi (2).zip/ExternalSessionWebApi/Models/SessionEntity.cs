using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ExternalSessionWebApi.Models
{
    [Table("Sessions")]
    public class SessionEntity
    {
        [Key]
        [StringLength(255)]
        public string SessionId { get; set; } = string.Empty;

        [Required]
        [StringLength(255)]
        public string UserId { get; set; } = string.Empty;

        public string DataJson { get; set; } = "{}";

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime LastAccessedAt { get; set; } = DateTime.UtcNow;

        public DateTime ExpiresAt { get; set; } = DateTime.UtcNow.AddHours(24);

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        [NotMapped]
        public bool IsExpired => DateTime.UtcNow > ExpiresAt;
    }
}
namespace ExternalSessionWebApi.Models
{
    public class SessionContext
    {
        public string SessionId { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public DateTime LastAccessedAt { get; set; }
        public bool IsAuthenticated { get; set; }
        public Dictionary<string, object> Data { get; set; } = new();
    }
}
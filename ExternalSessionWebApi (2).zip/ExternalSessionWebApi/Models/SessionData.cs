using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ExternalSessionWebApi.Models
{
    public class SessionData
    {
        [Required]
        public string SessionId { get; set; } = string.Empty;

        [Required]
        public string UserId { get; set; } = string.Empty;

        public Dictionary<string, object> Data { get; set; } = new();

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime LastAccessedAt { get; set; } = DateTime.UtcNow;

        public DateTime ExpiresAt { get; set; } = DateTime.UtcNow.AddHours(24);

        [JsonIgnore]
        public bool IsExpired => DateTime.UtcNow > ExpiresAt;
    }
}